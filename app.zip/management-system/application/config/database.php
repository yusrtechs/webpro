<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Database Settings
|--------------------------------------------------------------------------
|
*/

$active_group = 'default';
$query_builder = TRUE;

$db['default'] = array(
	'dsn'	=> '',
	'hostname' => 'localhost',
	'username' => 'cpesoft',
	'password' => 'enter-password',
	'database' => 'cpesoft_info',
	//'username' => 'root',
	//'password' => '',
	//'database' => 'sparkpos_info',
	'dbdriver' => 'mysqli',
	'dbprefix' => '',
	'pconnect' => FALSE,
	'db_debug' => (ENVIRONMENT !== 'production'),
	'cache_on' => FALSE,
	'cachedir' => '',
	'char_set' => 'utf8',
	'dbcollat' => 'utf8_general_ci',
	'swap_pre' => '',
	'encrypt' => FALSE,
	'compress' => FALSE,
	'stricton' => FALSE,
	'failover' => array(),
	'save_queries' => TRUE
);

$db['api'] = [
    'dsn'          => '',
    'hostname'     => 'localhost',
    'username' => 'cpesoft',
	'password' => 'enter-password',
	'database' => 'cpesoft_test',
	//'username' => 'root',
	//'password' => '',
	//'database' => 'sparkpos_info',
	'dbdriver'     => 'mysqli',
    'dbprefix'     => 'sma_',
    'pconnect'     => false,
    'db_debug'     => false,
    'cache_on'     => false,
    'cachedir'     => '',
    'char_set'     => 'utf8',
    'dbcollat'     => 'utf8_general_ci',
    'swap_pre'     => '',
    'encrypt'      => false,
    'compress'     => false,
    'stricton'     => false,
    'failover'     => [],
    'save_queries' => false,
];
