<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Carsoffers_model extends CI_Model
{
    public function __construct()
        {
            parent::__construct();
        }

        public function addQuote($data = [], $items = [])
        {
            if ($this->db->insert('carsquotes', $data)) {
                $quote_id = $this->db->insert_id();
                if ($this->site->getReference('of') == $data['reference_no']) {
                    $this->site->updateReference('of');
                }
                foreach ($items as $item) {
                    $item['quote_id'] = $quote_id;
                    $this->db->insert('carsquote_items', $item);
                }
                return true;
            }
            return false;
        }

        public function deleteQuote($id)
        {
            if ($this->db->delete('carsquote_items', ['quote_id' => $id]) && $this->db->delete('carsquotes', ['id' => $id])) {
                return true;
            }
            return false;
        }
        public function getAllQuoteItems($quote_id)
        {
            $this->db->select('carsquote_items.*, tax_rates.code as tax_code, tax_rates.name as tax_name, tax_rates.rate as tax_rate, products.unit, products.image, products.details as details, products.cf1 as cf1, products.cf2 as cf2, products.cf3 as cf3, products.cf4 as cf4, products.cf5 as cf5, products.cf6 as cf6, product_variants.name as variant, products.hsn_code as hsn_code, products.second_name as second_name')
                ->join('products', 'products.id=carsquote_items.product_id', 'left')
                ->join('product_variants', 'product_variants.id=carsquote_items.option_id', 'left')
                ->join('tax_rates', 'tax_rates.id=carsquote_items.tax_rate_id', 'left')
                ->group_by('carsquote_items.id')
                ->order_by('id', 'asc');
            $q = $this->db->get_where('carsquote_items', ['quote_id' => $quote_id]);
            if ($q->num_rows() > 0) {
                foreach (($q->result()) as $row) {
                    $data[] = $row;
                }
                return $data;
            }
            return false;
        }

        public function getAllQuoteItemsWithDetails($quote_id)
        {
            $this->db->select('carsquote_items.id, carsquote_items.product_name, carsquote_items.product_code, carsquote_items.quantity, carsquote_items.serial_no, carsquote_items.tax, carsquote_items.unit_price, carsquote_items.val_tax, carsquote_items.discount_val, carsquote_items.gross_total, products.details, products.hsn_code as hsn_code, products.second_name as second_name');
            $this->db->join('products', 'products.id=carsquote_items.product_id', 'left');
            $this->db->order_by('id', 'asc');
            $q = $this->db->get_where('carsquote_items', ['quote_id' => $quote_id]);
            if ($q->num_rows() > 0) {
                foreach (($q->result()) as $row) {
                    $data[] = $row;
                }
                return $data;
            }
        }

        public function getItemByID($id)
        {
            $q = $this->db->get_where('carsquote_items', ['id' => $id], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function getProductByCode($code)
        {
            $q = $this->db->get_where('products', ['code' => $code], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function getProductByName($name)
        {
            $q = $this->db->get_where('products', ['name' => $name], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function getProductComboItems($pid, $warehouse_id)
        {
            $this->db->select('products.id as id, combo_items.item_code as code, combo_items.quantity as qty, products.name as name, products.type as type, warehouses_products.quantity as quantity')
                ->join('products', 'products.code=combo_items.item_code', 'left')
                ->join('warehouses_products', 'warehouses_products.product_id=products.id', 'left')
                ->where('warehouses_products.warehouse_id', $warehouse_id)
                ->group_by('combo_items.id');
            $q = $this->db->get_where('combo_items', ['combo_items.product_id' => $pid]);
            if ($q->num_rows() > 0) {
                foreach (($q->result()) as $row) {
                    $data[] = $row;
                }

                return $data;
            }
            return false;
        }

        public function getProductNames($term, $warehouse_id, $limit = 5)
        {
            $this->db->select('products.*')
                ->join('warehouses_products', 'warehouses_products.product_id=products.id', 'left')
                ->group_by('products.id');

            $this->db->where("(name LIKE '%" . $term . "%' OR code LIKE '%" . $term . "%' OR  concat(name, ' (', code, ')') LIKE '%" . $term . "%')");

            $this->db->limit($limit);
            $q = $this->db->get('products');
            if ($q->num_rows() > 0) {
                foreach (($q->result()) as $row) {
                    $data[] = $row;
                }
                return $data;
            }
        }

        public function getProductOptionByID($id)
        {
            $q = $this->db->get_where('product_variants', ['id' => $id], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function getProductOptions($product_id, $warehouse_id)
        {
            $this->db->select('product_variants.id as id, product_variants.name as name, product_variants.price as price, product_variants.quantity as total_quantity, warehouses_products_variants.quantity as quantity')
                ->join('warehouses_products_variants', 'warehouses_products_variants.option_id=product_variants.id', 'left')
                //->join('warehouses', 'warehouses.id=product_variants.warehouse_id', 'left')
                ->where('product_variants.product_id', $product_id)
                ->where('warehouses_products_variants.warehouse_id', $warehouse_id)
                ->where('warehouses_products_variants.quantity >', 0)
                ->group_by('product_variants.id');
            $q = $this->db->get('product_variants');
            if ($q->num_rows() > 0) {
                foreach (($q->result()) as $row) {
                    $data[] = $row;
                }
                return $data;
            }
            return false;
        }

        public function getQuoteByID($id)
        {
            $q = $this->db->get_where('carsquotes', ['id' => $id], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function getWarehouseProductQuantity($warehouse_id, $product_id)
        {
            $q = $this->db->get_where('warehouses_products', ['warehouse_id' => $warehouse_id, 'product_id' => $product_id], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function getWHProduct($id)
        {
            $this->db->select('products.id, code, name, warehouses_products.quantity, cost, tax_rate')
                ->join('warehouses_products', 'warehouses_products.product_id=products.id', 'left')
                ->group_by('products.id');
            $q = $this->db->get_where('products', ['warehouses_products.product_id' => $id], 1);
            if ($q->num_rows() > 0) {
                return $q->row();
            }
            return false;
        }

        public function updateQuote($id, $data, $items = [])
        {
            if ($this->db->update('carsquotes', $data, ['id' => $id]) && $this->db->delete('carsquote_items', ['quote_id' => $id])) {
                foreach ($items as $item) {
                    $item['quote_id'] = $id;
                    $this->db->insert('carsquote_items', $item);
                }
                return true;
            }
            return false;
        }

        public function updateStatus($id, $status, $note)
        {
            if ($this->db->update('carsquotes', ['status' => $status, 'note' => $note], ['id' => $id])) {
                return true;
            }
            return false;
        }

}
