$(document).ready(function(e) {

    var old_item_tax;
    if ((slwarehouse = localStorage.getItem('slwarehouse'))) {
    //alert(slwarehouse)
        $('#slwarehouse').select2('val', slwarehouse);



        try{
            $.ajax({
                    type: 'get',
                    async: false,
                    url: site.base_url + 'products/getWarehouseById/' + localStorage.getItem('slwarehouse'),
                    dataType: 'json',
                    data: { id : localStorage.getItem('slwarehouse')},
                    success: function(data, page) {

                        if (data.isTobacco == 1) {
                            isTobacco=1;


                        }else{
                            isTobacco=0;
                        }

                    },
                });

            }catch(err){alert(err);}
    }

            try{
                localStorage.setItem('slpayment_status', 'pending');
                localStorage.setItem('paid_by', 'cash');
                localStorage.setItem('pcash_account_1', '');
                localStorage.setItem('amount_1', '');
                //alert($('#slcurrency').val())
                //if($('#slcurrency').val()==null)
                //localStorage.setItem('slcurrency', 'SR');

                //$('#amount_val_1').val($('#amount_1').val());
        $('#tax_method_type').change(function (e) {

        localStorage.setItem('stax_method_type', $(this).val());

                if($('#tax_method_type').val()==1){
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', false);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {
                    $("#div_product_tax").css("display", "none");
                    $('#ptax').val(1).trigger('change.select2');

                    $('#ptax').select2('readonly', true);
                    }
                    $('#sldiscount').val("").trigger('change');
                    $("#div_invoice_discount").css("display", "block");
                    //$('#pdiscount').val("0").trigger('change');
                    $("#div_product_discount").css("display", "none");
                    //$("#div_th_discount").css("display", "none");
                    //$("#div_th_tax").css("display", "none");


                }else{
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', true);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    //$("#div_product_tax").css("display", "none");
                    //$('#ptax').val(1).trigger('change.select2');

                    //$('#ptax').select2('readonly', false);
                    }
                    $('#sldiscount').val("").trigger('change');
                    $("#div_invoice_discount").css("display", "none");
                    //$('#pdiscount').val("0").trigger('change');
                    $("#div_product_discount").css("display", "block");
                    //$("#div_th_discount").css("display", "table-cell");
                    //$("#div_th_tax").css("display", "table-cell");



                }
            try{
             if(Object.keys(JSON.parse(localStorage.getItem('slitems'))).length >0)
                     $('#tax_method_type').select2('readonly', true);

            }catch(err){}

        });

        }catch(err){alert(err);}



                try{

                if (stax_method_type = localStorage.getItem('stax_method_type') && (Object.keys(JSON.parse(localStorage.getItem('slitems'))).length >0  && ((sldebit_id = localStorage.getItem('sldebit_id')) || (slcredit_id = localStorage.getItem('slcredit_id'))))) {
                    $('#tax_method_type').select2("val", localStorage.getItem('stax_method_type'));

                }
                }catch(err){}

                //if (stax_method_type = localStorage.getItem('stax_method_type')) {
                //	$('#tax_method_type').select2("val", stax_method_type);
                //}

                if($('#tax_method_type').val()==1){
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', false);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    $("#div_product_tax").css("display", "none");
                    $('#ptax').val(1).trigger('change.select2');

                    $('#ptax').select2('readonly', true);
                    }
                    $('#sldiscount').val("").trigger('change');
                    $("#div_invoice_discount").css("display", "block");
                    //$('#pdiscount').val("0").trigger('change');
                    $("#div_product_discount").css("display", "none");
                    //$("#div_th_discount").css("display", "none");
                    //$("#div_th_tax").css("display", "none");


                }else{
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', true);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    //$("#div_product_tax").css("display", "none");
                    //$('#ptax').val(1).trigger('change.select2');

                    //$('#ptax').select2('readonly', false);
                    }
                    $('#sldiscount').val("").trigger('change');
                    $("#div_invoice_discount").css("display", "none");
                    //$('#pdiscount').val("0").trigger('change');
                    $("#div_product_discount").css("display", "block");
                    //$("#div_th_discount").css("display", "table-cell");
                    //$("#div_th_tax").css("display", "table-cell");



                }

                if (!localStorage.getItem('stax_method_type')) {
                       localStorage.setItem('stax_method_type', '1');
                    }

        try{
             if((Object.keys(JSON.parse(localStorage.getItem('slitems'))).length >0 && ((sldebit_id = localStorage.getItem('sldebit_id')) || (slcredit_id = localStorage.getItem('slcredit_id')))))
                     $('#tax_method_type').select2('readonly', true);


        }catch(err){}





        $('body a, body button').attr('tabindex', -1);
        check_add_item_val();
        if (site.settings.set_focus != 1) {
            $('#add_item').focus();
        }
        var $customer = $('#slcustomer');

        $customer.change(function(e) {

            localStorage.setItem('slcustomer', $(this).val());
           // alert(localStorage.getItem('slcustomer'))
            //$('#slcustomer_id').val($(this).val());
            try{
            $.ajax({
                    type: 'get',
                    async: false,
                    url: site.base_url + 'customers/getCustomerco_type/' + localStorage.getItem('slcustomer'),
                    dataType: 'json',
                    data: { id : localStorage.getItem('slcustomer')},
                    success: function(data, page) {
                        if (isNaN(data.cf1))
                        $('#po_no').val(data.cf1);
                        /*if (data.co_type==2) {
                            $('#sltax2').val(1).trigger('change.select2');
                            $('#sltax2').select2('readonly', true);
                            $("#div_invoice_tax").css("display", "none");
                            if (site.settings.isOpen_invoice != 1) {

                            $("#div_product_tax").css("display", "none");
                            $('#ptax').val(1).trigger('change.select2');

                            $('#ptax').select2('readonly', true);
                            }
                            $('#tax_method_type').val(1).trigger('change.select2');
                            $('#tax_method_type').select2('readonly', true);


                        } else*/ {
                            $('#sltax2').select2('readonly', false);
                            $('#ptax').select2('readonly', false);
                            $("#div_invoice_tax").css("display", "none");
                            if (site.settings.isOpen_invoice != 1) {

                            //$("#div_product_tax").css("display", "none");
                            }
                            $('#tax_method_type').select2('readonly', false);
                            $('#slcurrency').select2('readonly', false);

                            if($('#tax_method_type').val()==1){
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', false);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    $("#div_product_tax").css("display", "none");
                    $('#ptax').val(1).trigger('change.select2');
                    $('#ptax').select2('readonly', true);
                    }

                }else{
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', true);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    //$("#div_product_tax").css("display", "none");
                    //$('#ptax').val(1).trigger('change.select2');
                    //$('#ptax').select2('readonly', false);
                    }


                }

                        }





                        try{
                            $.ajax({
                                    type: 'get',
                                    async: false,
                                    url: site.base_url + 'salesman/getSalesmanCustomer/' + localStorage.getItem('slcustomer'),
                                    dataType: 'json',
                                    data: { id : localStorage.getItem('slcustomer')},
                                    success: function(data, page) {
                                        if (data.salesman_id != null) {
                                            if(sl_edit){}else{
                                            $('#slsalesman').val(data.salesman_id).trigger('change.select2');
                                            }


                                        }else{
                                            if(sl_edit){}else{
                                                $('#slsalesman').val('').trigger('change.select2');
                                            }
                                        }

                                    },
                                });

                            }catch(err){alert(err);}




                    },
                });

            }catch(err){alert(err);}

        });
            try{
            $.ajax({
                    type: 'get',
                    async: false,
                    url: site.base_url + 'customers/getCustomerco_type/' + localStorage.getItem('slcustomer'),
                    dataType: 'json',
                    data: { id : localStorage.getItem('slcustomer')},
                    success: function(data, page) {
                        /*if (data.co_type==2) {
                            $('#sltax2').val(1).trigger('change.select2');
                            $('#sltax2').select2('readonly', true);
                            $("#div_invoice_tax").css("display", "none");
                            if (site.settings.isOpen_invoice != 1) {

                            $("#div_product_tax").css("display", "none");
                            $('#ptax').val(1).trigger('change.select2');
                            $('#ptax').select2('readonly', true);
                            }
                            $('#tax_method_type').val(1).trigger('change.select2');
                            $('#tax_method_type').select2('readonly', true);

                        } else*/ {
                            $('#sltax2').select2('readonly', false);
                            $("#div_invoice_tax").css("display", "none");
                            if (site.settings.isOpen_invoice != 1) {

                            //$("#div_product_tax").css("display", "none");
                            //$('#ptax').select2('readonly', false);
                            }
                            //$('#tax_method_type').select2('readonly', false);
                if($('#tax_method_type').val()==1){
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', false);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    $("#div_product_tax").css("display", "none");
                    $('#ptax').val(1).trigger('change.select2');
                    $('#ptax').select2('readonly', true);
                    }
                }else{
                    $('#sltax2').val(1).trigger('change.select2');
                    $('#sltax2').select2('readonly', true);
                    $("#div_invoice_tax").css("display", "none");
                    if (site.settings.isOpen_invoice != 1) {

                    //$("#div_product_tax").css("display", "none");
                    //$('#ptax').val(1).trigger('change.select2');
                    //$('#ptax').select2('readonly', false);
                    }

                }

                        }

                    },
                });

            }catch(err){alert(err);}

        if ((slcustomer = localStorage.getItem('slcustomer'))) {
            $customer.val(slcustomer).select2({
                minimumInputLength: 1,
                data: [],
                initSelection: function(element, callback) {
                    $.ajax({
                        type: 'get',
                        async: false,
                        url: site.base_url + 'customers/getCustomer/' + $(element).val(),
                        dataType: 'json',
                        success: function(data) {
                            callback(data[0]);
                        },
                    });
                },
                ajax: {
                    url: site.base_url + 'customers/suggestions',
                    dataType: 'json',
                    quietMillis: 15,
                    data: function(term, page) {
                        return {
                            term: term,
                            limit: 10,
                            grpId: localStorage.getItem('sgrpId'),
                            coId: localStorage.getItem('scoId'),
                            brId: localStorage.getItem('sbrId'),

                        };
                    },
                    results: function(data, page) {
                        //if (localStorage.getItem('sgrpId') && localStorage.getItem('scoId') && localStorage.getItem('sbrId')) {

                        if (data.results != null) {
                            return { results: data.results };
                        } else {
                            return { results: [{ id: '', text: 'No Match Found' }] };
                        }
                    /*}else{
                        bootbox.alert(lang.select_above);
                        return { results: [{ id: '', text: 'No Match Found' }] };
                    }*/

                    },
                },
            });

            try{
                $.ajax({
                        type: 'get',
                        async: false,
                        url: site.base_url + 'salesman/getSalesmanCustomer/' + localStorage.getItem('slcustomer'),
                        dataType: 'json',
                        data: { id : localStorage.getItem('slcustomer')},
                        success: function(data, page) {

                            if (data.salesman_id != null) {
                                if(sl_edit){}else{
                                $('#slsalesman').val(data.salesman_id).trigger('change.select2');
                                }


                            }else{
                                if(sl_edit){}else{
                                    $('#slsalesman').val('').trigger('change.select2');
                                }
                            }

                        },
                    });

                }catch(err){alert(err);}
        } else {
            nsCustomer();
        }




        $('#grpId').change(function () {
            localStorage.setItem('sgrpId', $(this).val());

            var v = $(this).val();
            var uopt = $("#coId");
           // console.log(uopt);

            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getCompaniesBygrpId/' + v,
                    dataType: "json",
                    success: function (scdata) {
                        if (scdata != null) {
                            $('#coId')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_main_company+'</option>')
    .val('')
    ;

    $('#brId')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_main_branch+'</option>')
    .val('')
    ;



    $('#coId').val('').trigger('change.select2');
    $('#brId').val('').trigger('change.select2');

    $('#slwarehouse').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#munit').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#mcategory').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#slbiller').select2("destroy").empty().select2({minimumResultsForSearch: 7});

    $('#sltax2').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#ptax').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#slcurrency').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    if (count == 1 && !(sldebit_id = localStorage.getItem('sldebit_id')) && !(slcredit_id = localStorage.getItem('slcredit_id'))) {
        localStorage.removeItem('slcustomer');

        $('#slcustomer').val('').trigger('change');
        }


                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt);

        });


                        } else {
                            $("#coId").select2("destroy").empty().attr("placeholder", lang.Select_main_company).select2({allowClear: true,
                                placeholder: lang.Select_main_company,
                                scdata: [{id: '', text: lang.Select_main_company}]
                            });
                            $('#slwarehouse').select2("destroy").empty().select2({minimumResultsForSearch: 7});
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#coId").select2("destroy").empty().attr("placeholder", lang.Select_main_company).select2({allowClear: true,
                    placeholder: lang.Select_main_company,
                    scdata: [{id: '', text: lang.Select_main_company}]
                });
            }
        });



        $('#coId').change(function () {
            localStorage.setItem('scoId', $(this).val());



            var v = $(this).val();
            var uopt = $("#brId");


            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getBranchesBycoId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {

                            $('#brId')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_main_branch+'</option>')
    .val('')
    ;


    $('#brId').val('').trigger('change.select2');

    $('#slwarehouse').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#munit').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#mcategory').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#slbiller').select2("destroy").empty().select2({minimumResultsForSearch: 7});

    $('#sltax2').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#ptax').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    $('#slcurrency').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    if (count == 1 && !(sldebit_id = localStorage.getItem('sldebit_id')) && !(slcredit_id = localStorage.getItem('slcredit_id'))) {
        localStorage.removeItem('slcustomer');

        $('#slcustomer').val('').trigger('change');
        }


                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt);

        });

                        } else {
                            $("#brId").select2("destroy").empty().attr("placeholder", lang.Select_main_branch).select2({allowClear: true,
                                placeholder: lang.Select_main_branch,
                                scdata: [{id: '', text: lang.Select_main_branch}]
                            });
                            $('#slwarehouse').select2("destroy").empty().select2({minimumResultsForSearch: 7});
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#brId").select2("destroy").empty().attr("placeholder", lang.Select_main_branch).select2({allowClear: true,
                    placeholder: lang.Select_main_branch,
                    scdata: [{id: '', text: lang.Select_main_branch}]
                });
            }
        });




        $('#brId').change(function () {

            localStorage.setItem('sbrId', $(this).val());


            var v = $(this).val();

            var uopt = $("#munit");
            var uopt1 = $("#slwarehouse");
            var uopt2 = $("#mcategory");
            var uopt3 = $("#slbiller");
            var uopt4 = $("#sltax2");
            var uopt5 = $("#ptax");
            var uopt6 = $("#slcurrency");






            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getWarehousesBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {


    //console.log(scdata[0])
    try{
    $('#slwarehouse').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    }catch(err){}
    if (count == 1 && !(sldebit_id = localStorage.getItem('sldebit_id')) && !(slcredit_id = localStorage.getItem('slcredit_id'))) {
    localStorage.removeItem('slcustomer');

    $('#slcustomer').val('').trigger('change');
    }


                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt1);

        });
        if ((slwarehouse = localStorage.getItem('slwarehouse'))) {
        $('#slwarehouse').val(slwarehouse).trigger('change.select2');
        }else{
            $('#slwarehouse').val(scdata[0].id).trigger('change.select2');
        }
                        } else {
                            $("#slwarehouse").select2("destroy").empty().attr("placeholder", lang.Select_warehouse).select2({allowClear: false,
                                placeholder: lang.Select_warehouse,
                                scdata: [{id: '', text: lang.Select_warehouse}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#slwarehouse").select2("destroy").empty().attr("placeholder", lang.Select_warehouse).select2({allowClear: false,
                    placeholder: lang.Select_warehouse,
                    scdata: [{id: '', text: lang.Select_warehouse}]
                });
            }



            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getUnitBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {


    //console.log(scdata[0])
    $('#munit').select2("destroy").empty().select2({minimumResultsForSearch: 7});




                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text + ' (' + this.code + ')'}).appendTo(uopt);

        });
        $('#munit').val(scdata[0].id).trigger('change.select2');
        var vu = $('#munit').val();

            if (vu) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'products/getSubUnits/' + vu +'/'+ v,
                    dataType: "json",
                    success: function (data) {
                        $('#default_sale_unit').select2("destroy").empty().select2({minimumResultsForSearch: 7});
                        $('#default_purchase_unit').select2("destroy").empty().select2({minimumResultsForSearch: 7});
                        $.each(data, function () {
                            $("<option />", {value: this.id, text: this.name+' ('+this.code+')'}).appendTo($('#default_sale_unit'));
                            $("<option />", {value: this.id, text: this.name+' ('+this.code+')'}).appendTo($('#default_purchase_unit'));
                        });
                        $('#default_sale_unit').select2('val', vu);
                        $('#default_purchase_unit').select2('val', vu);
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $('#default_sale_unit').select2("destroy").empty();
                $('#default_purchase_unit').select2("destroy").empty();
                $("<option />", {value: '', text: lang.select_unit_first}).appendTo($('#default_sale_unit'));
                $("<option />", {value: '', text: lang.select_unit_first}).appendTo($('#default_purchase_unit'));
                $('#default_sale_unit').select2({minimumResultsForSearch: 7}).select2('val', '');
                $('#default_purchase_unit').select2({minimumResultsForSearch: 7}).select2('val', '');
            }
                        } else {
                            $("#munit").select2("destroy").empty().attr("placeholder", lang.Select_unit).select2({allowClear: false,
                                placeholder: lang.Select_unit,
                                scdata: [{id: '', text: lang.Select_unit}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#munit").select2("destroy").empty().attr("placeholder", lang.Select_unit).select2({allowClear: false,
                    placeholder: lang.Select_unit,
                    scdata: [{id: '', text: lang.Select_unit}]
                });
            }


            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getCategoryBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {


    //console.log(scdata[0])
    $('#mcategory').select2("destroy").empty().select2({minimumResultsForSearch: 7});




                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt2);

        });
        $('#mcategory').val(scdata[0].id).trigger('change.select2');

        var vc = $('#mcategory').val();

        if (vc) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'products/getSubCategories/' + vc +'/'+ v,
                    dataType: "json",
                    success: function (scdata) {
                        if (scdata != null) {
                            scdata.push({id: '', text: lang.select_subcategory});
                            $("#subcategory").select2("destroy").empty().attr("placeholder", lang.select_subcategory).select2({
                                placeholder: lang.select_category_to_load,
                                minimumResultsForSearch: 7,
                                data: scdata
                            });
                        } else {
                            $("#subcategory").select2("destroy").empty().attr("placeholder", lang.no_subcategory).select2({
                                placeholder: lang.no_subcategory,
                                minimumResultsForSearch: 7,
                                data: [{id: '', text: lang.no_subcategory}]
                            });
                        }
                    },
                    error: function () {
                       // bootbox.alert('<?= lang('ajax_error') ?>');
                        $('#modal-loading').hide();
                    }
                });
            } else {
                $("#subcategory").select2("destroy").empty().attr("placeholder", lang.select_category_to_load).select2({
                    placeholder: lang.select_category_to_load,
                    minimumResultsForSearch: 7,
                    data: [{id: '', text: lang.select_category_to_load}]
                });
            }
                        } else {
                            $("#mcategory").select2("destroy").empty().attr("placeholder", lang.Select_category).select2({allowClear: false,
                                placeholder: lang.Select_category,
                                scdata: [{id: '', text: lang.Select_category}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#mcategory").select2("destroy").empty().attr("placeholder", lang.Select_category).select2({allowClear: false,
                    placeholder: lang.Select_category,
                    scdata: [{id: '', text: lang.Select_category}]
                });
            }


            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getBillersBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {



    $('#slbiller')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_biller+'</option>')
    .val('')
    ;




    try{
    $('#slbiller').select2("destroy").empty().select2({minimumResultsForSearch: 7});
    }catch(err){}

                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt3);

        });


        if (slbiller = localStorage.getItem('slbiller')) {
            $('#slbiller').val(slbiller).trigger('change.select2');;
        }else{
            $('#slbiller').val(scdata[0].id).trigger('change.select2');
        }

                        } else {
                            $("#slbiller").select2("destroy").empty().attr("placeholder", lang.Select_biller).select2({allowClear: true,
                                placeholder: lang.Select_biller,
                                scdata: [{id: '', text: lang.Select_biller}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#slbiller").select2("destroy").empty().attr("placeholder", lang.Select_biller).select2({allowClear: true,
                    placeholder: lang.Select_biller,
                    scdata: [{id: '', text: lang.Select_biller}]
                });
            }




            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getTaxBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {



    $('#sltax2')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_order_tax+'</option>')
    .val('')
    ;





    $('#sltax2').select2("destroy").empty().select2({minimumResultsForSearch: 7});


                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt4);

        });


        $('#sltax2').val(scdata[0].id).trigger('change.select2');

                        } else {
                            $("#sltax2").select2("destroy").empty().attr("placeholder", lang.Select_order_tax).select2({allowClear: true,
                                placeholder: lang.Select_order_tax,
                                scdata: [{id: '', text: lang.Select_order_tax}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#sltax2").select2("destroy").empty().attr("placeholder", lang.Select_order_tax).select2({allowClear: true,
                    placeholder: lang.Select_order_tax,
                    scdata: [{id: '', text: lang.Select_order_tax}]
                });
            }




            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getTaxBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {



    $('#ptax')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_product_tax+'</option>')
    .val('')
    ;





    $('#ptax').select2("destroy").empty().select2({minimumResultsForSearch: 7});


                            $.each(scdata, function () {
                $("<option />", {value: this.id, text: this.text}).appendTo(uopt5);

        });


        $('#ptax').val(scdata[0].id).trigger('change.select2');

                        } else {
                            $("#ptax").select2("destroy").empty().attr("placeholder", lang.Select_product_tax).select2({allowClear: true,
                                placeholder: lang.Select_product_tax,
                                scdata: [{id: '', text: lang.Select_product_tax}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#ptax").select2("destroy").empty().attr("placeholder", lang.Select_product_tax).select2({allowClear: true,
                    placeholder: lang.Select_product_tax,
                    scdata: [{id: '', text: lang.Select_product_tax}]
                });
            }



            if (v) {
                $.ajax({
                    type: "get",
                    async: false,
                    url: site.base_url + 'branches/getCurrenciesBybrId/' + v,
                    dataType: "json",
                    success: function (scdata) {

                        if (scdata != null) {



    $('#slcurrency')
    .find('option')
    .remove()
    .end()
    .append('<option value="">'+lang.Select_currency+'</option>')
    .val('')
    ;





    $('#slcurrency').select2("destroy").empty().select2({minimumResultsForSearch: 7});


                            $.each(scdata, function () {
                $("<option />", {value: this.code, text: this.text}).appendTo(uopt6);

        });


        $('#slcurrency').val(scdata[0].code).trigger('change.select2');

                        } else {
                            $("#slcurrency").select2("destroy").empty().attr("placeholder", lang.Select_currency).select2({allowClear: true,
                                placeholder: lang.Select_currency,
                                scdata: [{code: '', text: lang.Select_currency}]
                            });
                        }
                    },
                    error: function () {
                        //bootbox.alert('<?= lang('ajax_error') ?>');
                    }
                });
            } else {
                $("#slcurrency").select2("destroy").empty().attr("placeholder", lang.Select_currency).select2({allowClear: true,
                    placeholder: lang.Select_currency,
                    scdata: [{code: '', text: lang.Select_currency}]
                });
            }





        });

        // Order level shipping and discount localStorage
        if ((sldiscount = localStorage.getItem('sldiscount'))) {
            $('#sldiscount').val(sldiscount);
        }
        $('#sltax2').change(function(e) {
            localStorage.setItem('sltax2', $(this).val());
            $('#sltax2').val($(this).val());
        });
        if ((sltax2 = localStorage.getItem('sltax2'))) {
            $('#sltax2').select2('val', sltax2);
        }
        $('#slsale_status').change(function(e) {
            localStorage.setItem('slsale_status', $(this).val());
            var ss = $(this).val();
            if (ss == 'completed') {
                $('#CostCenters').slideDown();


            } else {
                $('#CostCenters').slideUp();

            }



        });
        if ((slsale_status = localStorage.getItem('slsale_status'))) {
            $('#slsale_status').select2('val', slsale_status);

        }
        $('#slpayment_status').change(function(e) {
            var ps = $(this).val();
            localStorage.setItem('slpayment_status', ps);


            if (ps == 'partial' || ps == 'paid') {
                if (ps == 'paid') {

                    var amount=formatDecimal(parseFloat(total + invoice_tax - order_discount + shipping));
                    if (site.settings.isDonation != 0) {
                    var amountceil=Math.ceil(amount);

                    $('#amount_1').val(formatDecimal(amountceil));
                    $('#amount_val_1').val($('#amount_1').val());

                    $('#donation_1').val(formatDecimal(parseFloat(amountceil- amount)));
                    $('#donation_val_1').val($('#donation_1').val());
                    }else{
                    $('#amount_1').val(amount);
                    $('#amount_val_1').val($('#amount_1').val());
                    $('#donation_val_1').val(0);
                    }
                    //$('#amount_1').val(0);
                }
                $('#payments').slideDown();
                $('#pcc_no_1').focus();
                $('#payment-button').css("display", "block");


            } else {
                $('#payments').slideUp();
                $('#payment-button').css("display", "none");

            }
        });
        if ((slpayment_status = localStorage.getItem('slpayment_status'))) {
            $('#slpayment_status').select2('val', slpayment_status);
            var ps = slpayment_status;
            if (ps == 'partial' || ps == 'paid') {
                $('#payments').slideDown();
                $('#pcc_no_1').focus();
            } else {
                $('#payments').slideUp();
            }
        }

        /*$(document).on('change', '.paid_by', function() {
            var p_val = $(this).val();
            localStorage.setItem('paid_by', p_val);
            $('#rpaidby').val(p_val);
            if (p_val == 'cash' || p_val == 'other') {
                $('.pcheque_1').hide();
                $('.pcc_1').hide();
                $('.pcash_1').show();
                $('#payment_note_1').focus();
            } else if (p_val == 'CC') {
                $('.pcheque_1').hide();
                $('.pcash_1').hide();
                $('.pcc_1').show();
                $('#pcc_no_1').focus();
            } else if (p_val == 'Cheque') {
                $('.pcc_1').hide();
                $('.pcash_1').hide();
                $('.pcheque_1').show();
                $('#cheque_no_1').focus();
            } else {
                $('.pcheque_1').hide();
                $('.pcc_1').hide();
                $('.pcash_1').hide();
            }
            if (p_val == 'gift_card') {
                $('.gc').show();
                $('.ngc').hide();
                $('#gift_card_no').focus();
            } else {
                $('.ngc').show();
                $('.gc').hide();
                $('#gc_details').html('');
            }
        });*/

        $(document).on('change', '.paid_by', function () {
                var p_val = $(this).val(),
                    id = $(this).attr('id'),
                    pa_no = id.substr(id.length - 1);
                    //$('.paid_by').select2('val', paid_by);
                $('#rpaidby').val(p_val);
                if (p_val == 'cash' || p_val == 'other') {
                    $('.pcheque_' + pa_no).hide();
                    $('.pcc_' + pa_no).hide();
                    $('.ptransfer_' + pa_no).hide();
                    $('.pcash_' + pa_no).show();
                    $('#amount_' + pa_no).focus();
                } else if (p_val == 'CC' || p_val == 'stripe' || p_val == 'ppp' || p_val == 'authorize') {
                    $('.pcheque_' + pa_no).hide();
                    $('.pcash_' + pa_no).hide();
                    $('.ptransfer_' + pa_no).hide();
                    $('.pcc_' + pa_no).show();
                    $('#swipe_' + pa_no).focus();
                } else if (p_val == 'Cheque') {
                    $('.pcc_' + pa_no).hide();
                    $('.pcash_' + pa_no).hide();
                    $('.ptransfer_' + pa_no).hide();
                    $('.pcheque_' + pa_no).show();
                    $('#cheque_no_' + pa_no).focus();
                } else if (p_val == 'bank_transfer') {
                    $('.pcc_' + pa_no).hide();
                    $('.pcash_' + pa_no).hide();
                    $('.pcheque_' + pa_no).hide();
                    $('.ptransfer_' + pa_no).show();

                } else {
                    $('.pcheque_' + pa_no).hide();
                    $('.pcc_' + pa_no).hide();
                    $('.pcash_' + pa_no).hide();
                    $('.ptransfer_' + pa_no).hide();
                }

                if (p_val == 'gift_card') {
                    $('.gc_' + pa_no).show();
                    //$('.ngc_' + pa_no).hide();
                    $('#gift_card_no_' + pa_no).focus();
                } else {
                    //$('.ngc_' + pa_no).show();
                    $('.gc_' + pa_no).hide();
                    $('#gc_details_' + pa_no).html('');
                }
            });


        if ((paid_by = localStorage.getItem('paid_by'))) {
            var p_val = paid_by;
            $('.paid_by').select2('val', paid_by);
            $('#rpaidby').val(p_val);
            if (p_val == 'cash' || p_val == 'other') {
                $('.pcheque_1').hide();
                $('.pcc_1').hide();
                $('.ptransfer_1').hide();
                $('.pcash_1').show();
                $('#payment_note_1').focus();
            } else if (p_val == 'CC') {
                $('.pcheque_1').hide();
                $('.pcash_1').hide();
                $('.ptransfer_1').hide();
                $('.pcc_1').show();
                $('#pcc_no_1').focus();
            } else if (p_val == 'Cheque') {
                $('.pcc_1').hide();
                $('.pcash_1').hide();
                $('.ptransfer_1').hide();
                $('.pcheque_1').show();
                $('#cheque_no_1').focus();
            } else if (p_val == 'bank_transfer') {
                    $('.pcc_1').hide();
                    $('.pcash_1').hide();
                    $('.pcheque_1').hide();
                    $('.ptransfer_1').show();

            } else {
                $('.pcheque_1').hide();
                $('.pcc_1').hide();
                $('.pcash_1').hide();
            }
            if (p_val == 'gift_card') {
                $('.gc').show();
                $('.ngc').hide();
                $('#gift_card_no').focus();
            } else {
                $('.ngc').show();
                $('.gc').hide();
                $('#gc_details').html('');
            }
        }

        if ((gift_card_no = localStorage.getItem('gift_card_no'))) {
            $('#gift_card_no').val(gift_card_no);
        }
        $('#gift_card_no').change(function(e) {
            localStorage.setItem('gift_card_no', $(this).val());
        });

        if ((amount_1 = localStorage.getItem('amount_1'))) {
            $('#amount_1').val(amount_1);
        }
        $('#amount_1').change(function(e) {
            localStorage.setItem('amount_1', $(this).val());
        });

        if ((paid_by_1 = localStorage.getItem('paid_by_1'))) {
            $('#paid_by_1').val(paid_by_1);
        }
        $('#paid_by_1').change(function(e) {
            localStorage.setItem('paid_by_1', $(this).val());
        });

        if ((pcc_holder_1 = localStorage.getItem('pcc_holder_1'))) {
            $('#pcc_holder_1').val(pcc_holder_1);
        }
        $('#pcc_holder_1').change(function(e) {
            localStorage.setItem('pcc_holder_1', $(this).val());
        });

        if ((pcc_type_1 = localStorage.getItem('pcc_type_1'))) {
            $('#pcc_type_1').select2('val', pcc_type_1);
        }
        $('#pcc_type_1').change(function(e) {
            localStorage.setItem('pcc_type_1', $(this).val());
        });

        if ((pcash_account_1 = localStorage.getItem('pcash_account_1'))) {
            $('#pcash_account_1').select2('val', pcash_account_1);
        }
        $('#pcash_account_1').change(function(e) {
            localStorage.setItem('pcash_account_1', $(this).val());
        });

        if ((pcc_account_1 = localStorage.getItem('pcc_account_1'))) {
            $('#pcc_account_1').select2('val', pcc_account_1);
        }
        $('#pcc_account_1').change(function(e) {
            localStorage.setItem('pcc_account_1', $(this).val());
        });





        if ((pcheque_account_1 = localStorage.getItem('pcheque_account_1'))) {
            $('#pcheque_account_1').select2('val', pcheque_account_1);
        }
        $('#pcheque_account_1').change(function(e) {
            localStorage.setItem('pcheque_account_1', $(this).val());
        });




        if ((ptransfer_account_1 = localStorage.getItem('ptransfer_account_1'))) {
            $('#ptransfer_account_1').select2('val', ptransfer_account_1);
        }
        $('#ptransfer_account_1').change(function(e) {
            localStorage.setItem('ptransfer_account_1', $(this).val());
        });

        if ((pcc_month_1 = localStorage.getItem('pcc_month_1'))) {
            $('#pcc_month_1').val(pcc_month_1);
        }
        $('#pcc_month_1').change(function(e) {
            localStorage.setItem('pcc_month_1', $(this).val());
        });

        if ((pcc_year_1 = localStorage.getItem('pcc_year_1'))) {
            $('#pcc_year_1').val(pcc_year_1);
        }
        $('#pcc_year_1').change(function(e) {
            localStorage.setItem('pcc_year_1', $(this).val());
        });

        if ((pcc_no_1 = localStorage.getItem('pcc_no_1'))) {
            $('#pcc_no_1').val(pcc_no_1);
        }
        $('#pcc_no_1').change(function(e) {
            var pcc_no = $(this).val();
            localStorage.setItem('pcc_no_1', pcc_no);
            var CardType = null;
            var ccn1 = pcc_no.charAt(0);
            if (ccn1 == 4) CardType = 'Visa';
            else if (ccn1 == 5) CardType = 'MasterCard';
            else if (ccn1 == 3) CardType = 'Amex';
            else if (ccn1 == 6) CardType = 'Discover';
            else CardType = 'Visa';

            $('#pcc_type_1').select2('val', CardType);
        });

        if ((cheque_no_1 = localStorage.getItem('cheque_no_1'))) {
            $('#cheque_no_1').val(cheque_no_1);
        }
        $('#cheque_no_1').change(function(e) {
            localStorage.setItem('cheque_no_1', $(this).val());
        });
       if ((bank_transfer_no_1 = localStorage.getItem('bank_transfer_no_1'))) {
            $('#bank_transfer_no_1').val(cheque_no_1);
        }
        $('#bank_transfer_no_1').change(function(e) {
            localStorage.setItem('bank_transfer_no_1', $(this).val());
        });

        if ((payment_note_1 = localStorage.getItem('payment_note_1'))) {
            $('#payment_note_1').redactor('set', payment_note_1);
        }
        $('#payment_note_1').redactor('destroy');
        $('#payment_note_1').redactor({
            buttons: [
                'formatting',
                '|',
                'alignleft',
                'aligncenter',
                'alignright',
                'justify',
                '|',
                'bold',
                'italic',
                'underline',
                '|',
                'unorderedlist',
                'orderedlist',
                '|',
                'link',
                '|',
                'html',
            ],
            formattingTags: ['p', 'pre', 'h3', 'h4'],
            minHeight: 100,
            changeCallback: function(e) {
                var v = this.get();
                localStorage.setItem('payment_note_1', v);
            },
        });

        var old_payment_term;
        $('#slpayment_term')
            .focus(function() {
                old_payment_term = $(this).val();
            })
            .change(function(e) {
                var new_payment_term = $(this).val() ? parseFloat($(this).val()) : 0;
                if (!is_numeric($(this).val())) {
                    $(this).val(old_payment_term);
                    bootbox.alert(lang.unexpected_value);
                    return;
                } else {
                    localStorage.setItem('slpayment_term', new_payment_term);
                    $('#slpayment_term').val(new_payment_term);
                }
            });
        if ((slpayment_term = localStorage.getItem('slpayment_term'))) {
            $('#slpayment_term').val(slpayment_term);
        }

        var old_shipping;
        $('#slshipping')
            .focus(function() {
                old_shipping = $(this).val();
            })
            .change(function() {
                var slsh = $(this).val() ? $(this).val() : 0;
                if (!is_numeric(slsh)) {
                    $(this).val(old_shipping);
                    bootbox.alert(lang.unexpected_value);
                    return;
                }
                shipping = parseFloat(slsh);
                localStorage.setItem('slshipping', shipping);
                var gtotal = total + invoice_tax - order_discount + shipping;
                $('#gtotal').text(formatMoney(gtotal,localStorage.getItem('slcurrency')));
                $('#tship').text(formatMoney(shipping,localStorage.getItem('slcurrency')));
            });
        if ((slshipping = localStorage.getItem('slshipping'))) {
            shipping = parseFloat(slshipping);
            $('#slshipping').val(shipping);
        } else {
            shipping = 0;
        }
        $('#add_sale, #edit_sale').attr('disabled', true);
        $(document).on('change', '.rserial', function() {
            var item_id = $(this)
                .closest('tr')
                .attr('data-item-id');
            slitems[item_id].row.serial = $(this).val();
            localStorage.setItem('slitems', JSON.stringify(slitems));
        });

        // If there is any item in localStorage
        if (localStorage.getItem('slitems')) {
            loadItems();
        }

        // clear localStorage and reload



        $('#reset').click(function(e) {
            bootbox.confirm(lang.r_u_sure, function(result) {
                if (result) {
                    if (localStorage.getItem('sldebit_id')) {
                        localStorage.removeItem('sldebit_id');
                    }
                    if (localStorage.getItem('slcredit_id')) {
                        localStorage.removeItem('slcredit_id');
                    }
                    if (localStorage.getItem('stax_method_type')) {
                        localStorage.removeItem('stax_method_type');
                    }
                    if (localStorage.getItem('slitems')) {
                        localStorage.removeItem('slitems');
                    }
                    if (localStorage.getItem('sldiscount')) {
                        localStorage.removeItem('sldiscount');
                    }
                    if (localStorage.getItem('sltax2')) {
                        localStorage.removeItem('sltax2');
                    }
                    if (localStorage.getItem('slshipping')) {
                        localStorage.removeItem('slshipping');
                    }
                    if (localStorage.getItem('slref')) {
                        localStorage.removeItem('slref');
                    }
                    if (localStorage.getItem('slwarehouse')) {
                        localStorage.removeItem('slwarehouse');
                    }
                    if (localStorage.getItem('sgrpId')) {
                        localStorage.removeItem('sgrpId');
                    }
                    if (localStorage.getItem('scoId')) {
                        localStorage.removeItem('scoId');
                    }
                    if (localStorage.getItem('sbrId')) {
                        localStorage.removeItem('sbrId');
                    }
                    if (localStorage.getItem('slnote')) {
                        localStorage.removeItem('slnote');
                    }
                    if (localStorage.getItem('slinnote')) {
                        localStorage.removeItem('slinnote');
                    }
                    if (localStorage.getItem('slcustomer')) {
                        localStorage.removeItem('slcustomer');
                    }
                    if (localStorage.getItem('slcurrency')) {
                        localStorage.removeItem('slcurrency');
                    }
                    if (localStorage.getItem('slsrc_reference_no')) {
                        localStorage.removeItem('slsrc_reference_no');
                    }
                    if (localStorage.getItem('slinv_src')) {
                        localStorage.removeItem('slinv_src');
                    }
                    if (localStorage.getItem('sldate')) {
                        localStorage.removeItem('sldate');
                    }
                    if (localStorage.getItem('slstatus')) {
                        localStorage.removeItem('slstatus');
                    }
                    if (localStorage.getItem('slbiller')) {
                        localStorage.removeItem('slbiller');
                    }
                    if (localStorage.getItem('gift_card_no')) {
                        localStorage.removeItem('gift_card_no');
                    }

                    $('#modal-loading').show();
                    location.reload();
                }
            });
        });

        // save and load the fields in and/or from localStorage

        $('#slref').change(function(e) {
            localStorage.setItem('slref', $(this).val());
        });
        if ((slref = localStorage.getItem('slref'))) {
            $('#slref').val(slref);
        }

        $('#slwarehouse').change(function(e) {
            localStorage.setItem('slwarehouse', $(this).val());
            try{
                $.ajax({
                        type: 'get',
                        async: false,
                        url: site.base_url + 'products/getWarehouseById/' + $(this).val(),
                        dataType: 'json',
                        data: { id : $(this).val()},
                        success: function(data, page) {

                            if (data.isTobacco == 1) {
                                isTobacco=1;


                            }else{
                                isTobacco=0;
                            }

                        },
                    });

                }catch(err){alert(err);}
        });
        if ((slwarehouse = localStorage.getItem('slwarehouse'))) {

            $('#slwarehouse').select2('val', slwarehouse);



            try{
                $.ajax({
                        type: 'get',
                        async: false,
                        url: site.base_url + 'products/getWarehouseById/' + localStorage.getItem('slwarehouse'),
                        dataType: 'json',
                        data: { id : localStorage.getItem('slwarehouse')},
                        success: function(data, page) {

                            if (data.isTobacco == 1) {
                                isTobacco=1;


                            }else{
                                isTobacco=0;
                            }

                        },
                    });

                }catch(err){alert(err);}
        }

        if ((sgrpId = localStorage.getItem('sgrpId')) && site.settings.isGrouping==1) {
            $('#grpId').select2('val', sgrpId);

            try{
                $.ajax({
                        type: 'get',
                        async: false,
                        url: site.base_url + 'branches/getCompaniesBygrpId/' + localStorage.getItem('sgrpId'),
                        dataType: 'json',
                        data: { grpId : localStorage.getItem('sgrpId')},
                        success: function(data, page) {
                            $.each(data, function () {
                                $("<option />", {value: this.id, text: this.text}).appendTo($("#coId"));

                        });

                        },
                    });

                }catch(err){alert(err);}
        }

        if ((scoId = localStorage.getItem('scoId')) && site.settings.isGrouping==1) {
            $('#coId').select2('val', scoId);
            try{
                $.ajax({
                        type: 'get',
                        async: false,
                        url: site.base_url + 'branches/getBranchesBycoId/' + localStorage.getItem('scoId'),
                        dataType: 'json',
                        data: { coId : localStorage.getItem('scoId')},
                        success: function(data, page) {
                            $.each(data, function () {
                                $("<option />", {value: this.id, text: this.text}).appendTo($("#brId"));

                        });

                        },
                    });

                }catch(err){alert(err);}
        }

        if ((sbrId = localStorage.getItem('sbrId'))) {
            $('#brId').select2('val', sbrId).trigger('change');


        }

        $('#slcurrency').change(function(e) {
            localStorage.setItem('slcurrency', $(this).val());


            try{
            $.ajax({
                    type: 'get',
                    async: false,
                    url: site.base_url + 'sales/getCurrencyByCode/' + localStorage.getItem('slcurrency'),
                    dataType: 'json',
                    data: { code : localStorage.getItem('slcurrency')},
                    success: function(data, page) {
                        //data.co_type
                        //alert(data.rate);
                        currRate=data.rate;
                    },
                });

            }catch(err){alert(err);}

                        //alert();


        });
        if ((slcurrency = localStorage.getItem('slcurrency'))) {
            $('#slcurrency').select2('val', slcurrency);




        }

        $('#slinv_src').change(function(e) {
            localStorage.setItem('slinv_src', $(this).val());
            if ($(this).val() > 0) {
                $('.inv_src').show();
            } else {
                $('.inv_src').hide();
            }
        });

        if ((slinv_src = localStorage.getItem('slinv_src'))) {
            $('#slinv_src').select2('val', slinv_src);

        }

        if ((slsrc_reference_no = localStorage.getItem('slsrc_reference_no'))) {
            if(slsrc_reference_no > 0){
                $('#slinv_src').select2('readonly', true);
            }else{
                $('#slinv_src').select2('readonly', false);
            }


        }

        if ($('#slinv_src').val() > 0) {
            $('.inv_src').show();
        } else {
            $('.inv_src').hide();
        }


         $('#slsrc_reference_no').change(function(e) {
            var v = $(this).val();
            localStorage.setItem('slsrc_reference_no', v);
            if (v) {
                try{
            $.ajax({
                    type: 'get',
                    async: false,
                    url: site.base_url + 'sales/getSRCReferenceByCode',
                    dataType: 'json',
                    data: { ref : v,inv_src : $('#slinv_src').val()},
                    success: function(data, page) {
                        //data.co_type
                        if(data){
                            $('#slinv_src').select2('readonly', true);
                            if($('#slinv_src').val()==1){
                                window.location.href =  site.base_url + 'sales/add/'+data.id;
                            }else if($('#slinv_src').val()==2){
                                window.location.href =  site.base_url + 'sales/add/0/'+data.id;
                            }
                        }else{
                            bootbox.alert('No Match Found');
                            localStorage.setItem('slsrc_reference_no', '');
                        }

                    },
                    error: function () {
                        bootbox.alert('No Match Found');
                        localStorage.setItem('slsrc_reference_no', '');
                    }
                });

            }catch(err){alert(err);}

                        //alert();



            } else {
                bootbox.alert('No Match Found');
            }
        });

        $('#slnote').redactor('destroy');
        $('#slnote').redactor({
            buttons: [
                'formatting',
                '|',
                'alignleft',
                'aligncenter',
                'alignright',
                'justify',
                '|',
                'bold',
                'italic',
                'underline',
                '|',
                'unorderedlist',
                'orderedlist',
                '|',
                'link',
                '|',
                'html',
            ],
            formattingTags: ['p', 'pre', 'h3', 'h4'],
            minHeight: 100,
            changeCallback: function(e) {
                var v = this.get();
                localStorage.setItem('slnote', v);
            },
        });
        if ((slnote = localStorage.getItem('slnote'))) {
            $('#slnote').redactor('set', slnote);
        }
        $('#slinnote').redactor('destroy');
        $('#slinnote').redactor({
            buttons: [
                'formatting',
                '|',
                'alignleft',
                'aligncenter',
                'alignright',
                'justify',
                '|',
                'bold',
                'italic',
                'underline',
                '|',
                'unorderedlist',
                'orderedlist',
                '|',
                'link',
                '|',
                'html',
            ],
            formattingTags: ['p', 'pre', 'h3', 'h4'],
            minHeight: 100,
            changeCallback: function(e) {
                var v = this.get();
                localStorage.setItem('slinnote', v);
            },
        });
        if ((slinnote = localStorage.getItem('slinnote'))) {
            $('#slinnote').redactor('set', slinnote);
        }

        // prevent default action usln enter
        $('body').bind('keypress', function(e) {
            if ($(e.target).hasClass('redactor_editor')) {
                return true;
            }
            if (e.keyCode == 13) {
                e.preventDefault();
                return false;
            }
        });

        // Order tax calculation
        if (site.settings.tax2 != 0) {
            $('#sltax2').change(function() {
                localStorage.setItem('sltax2', $(this).val());
                loadItems();
                return;
            });
        }

        // Order discount calculation
        var old_sldiscount;
        $('#sldiscount')
            .focus(function() {
                old_sldiscount = $(this).val();
            })
            .change(function() {
                var new_discount = $(this).val() ? $(this).val() : '0';
                if (is_valid_discount(new_discount)) {
                    localStorage.removeItem('sldiscount');
                    localStorage.setItem('sldiscount', new_discount);

                     loadItems();
                    return;
                } else {
                    $(this).val(old_sldiscount);
                    bootbox.alert(lang.unexpected_value);
                    return;
                }
            });

        /* ----------------------
         * Delete Row Method
         * ---------------------- */
        $(document).on('click', '.sldel', function() {
            var row = $(this).closest('tr');
            var item_id = row.attr('data-item-id');
            delete slitems[item_id];
            row.remove();
            if($('#slTable tr').length==2){
                try{
                 if(Object.keys(JSON.parse(localStorage.getItem('slitems'))).length >0)
                     $('#tax_method_type').select2('readonly', false);
                 $('#slcurrency').select2('readonly', false);
                }catch(err){}

            }

            if (slitems.hasOwnProperty(item_id)) {
            } else {
                localStorage.setItem('slitems', JSON.stringify(slitems));
                loadItems();
                return;
            }
        });

        /* -----------------------
         * Edit Row Modal Hanlder
         ----------------------- */
        $(document).on('click', '.edit', function() {
            var row = $(this).closest('tr');
            var row_id = row.attr('id');
            item_id = row.attr('data-item-id');
            item = slitems[item_id];
            var qty = row
                    .children()
                    .children('.rquantity')
                    .val(),
                product_option = row
                    .children()
                    .children('.roption')
                    .val(),
                unit_price = formatDecimal(
                    row
                        .children()
                        .children('.realuprice')
                        .val()
                ),
                discount = row
                    .children()
                    .children('.rdiscount')
                    .val();
            if (item.options !== false) {
                $.each(item.options, function() {
                    if (this.id == item.row.option && this.price != 0 && this.price != '' && this.price != null) {
                        unit_price = parseFloat(item.row.real_unit_price) + parseFloat(this.price);
                    }
                });
            }

            var real_unit_price = item.row.real_unit_price;
            var net_price = unit_price;
            $('#prModalLabel').text(item.row.name + ' (' + item.row.code + ')');
            if (site.settings.tax1) {
                $('#ptax').select2('val', item.row.tax_rate);
                $('#old_tax').val(item.row.tax_rate);

                var pr_tax = item.row.tax_rate,
                    pr_tax_val = 0;
                if (pr_tax !== null && pr_tax != 0) {
                    $.each(tax_rates, function() {
                        if (this.id == pr_tax) {

                            if (this.type == 1) {
                                if (slitems[item_id].row.tax_method == 0) {
                                    pr_tax_val = formatDecimal((net_price * parseFloat(this.rate)) / (100 + parseFloat(this.rate)), 12);
                                    //pr_tax_val = formatDecimal((net_price * parseFloat(this.rate)) / (100 ), 12);
                                    pr_tax_rate = formatDecimal(this.rate,12) + '%';
                                    net_price -= pr_tax_val;
                                } else {
                                    pr_tax_val = formatDecimal((net_price * parseFloat(this.rate)) / 100, 12);
                                    pr_tax_rate = formatDecimal(this.rate,12) + '%';
                                }
                            } else if (this.type == 2) {
                                pr_tax_val = parseFloat(this.rate,12);
                                pr_tax_rate = this.rate;
                            }
                        }
                    });
                }


                var item_discount = 0,
                    ds = discount ? discount : '0';
                if (ds.indexOf('%') !== -1) {
                    var pds = ds.split('%');
                    if (!isNaN(pds[0])) {
                        item_discount = formatDecimal(parseFloat((net_price * parseFloat(pds[0])) / 100), 12);
                    } else {
                        item_discount = parseFloat(ds);
                    }
                } else {
                    item_discount = parseFloat(ds);
                }



                net_price -= item_discount;


                var pr_tax = item.row.tax_rate,
                    pr_tax_val = 0;

                if (pr_tax !== null && pr_tax != 0) {
                    $.each(tax_rates, function() {
                        if (this.id == pr_tax) {

                            if (this.type == 1) {
                                if (slitems[item_id].row.tax_method == 0) {
                                    //pr_tax_val = formatDecimal((net_price * parseFloat(this.rate)) / (100 + parseFloat(this.rate)), 12);
                                    pr_tax_val = formatDecimal((net_price * parseFloat(this.rate)) / (100 ), 12);
                                    pr_tax_rate = formatDecimal(this.rate,12) + '%';
                                    //net_price -= pr_tax_val;
                                } else {
                                    pr_tax_val = formatDecimal((net_price * parseFloat(this.rate)) / 100, 12);
                                    pr_tax_rate = formatDecimal(this.rate,12) + '%';
                                }
                            } else if (this.type == 2) {
                                pr_tax_val = parseFloat(this.rate,12);
                                pr_tax_rate = this.rate;
                            }
                        }
                    });
                }
            }

            if (site.settings.product_serial !== 0) {
                $('#pserial').val(
                    row
                        .children()
                        .children('.rserial')
                        .val()
                );
            }
            var opt = '<p style="margin: 12px 0 0 0;">n/a</p>';
            if (item.options !== false) {
                var o = 1;
                opt = $('<select id="poption" name="poption" class="form-control select" />');
                $.each(item.options, function() {
                    if (o == 1) {
                        if (product_option == '') {
                            product_variant = this.id;
                        } else {
                            product_variant = product_option;
                        }
                    }
                    $('<option />', { value: this.id, text: this.name }).appendTo(opt);
                    o++;
                });
            } else {
                product_variant = 0;
            }

            uopt = '<p style="margin: 12px 0 0 0;">n/a</p>';
            if (site.settings.isOpen_invoice == 1 && !item.units) {

                if (base_units) {
                    uopt = $('<select id="punit" name="punit" class="form-control select" />');
                    $.each(base_units, function() {
                        if (this.id == item.row.unit) {
                            $('<option />', { value: this.id, text: this.name, selected: true }).appendTo(uopt);
                        } else {
                            $('<option />', { value: this.id, text: this.name }).appendTo(uopt);
                        }
                    });
                }
            }else{

            if (item.units) {
                uopt = $('<select id="punit" name="punit" class="form-control select" />');
                $.each(item.units, function() {
                    if (this.id == item.row.unit) {
                        $('<option />', { value: this.id, text: this.name, selected: true }).appendTo(uopt);
                    } else {
                        $('<option />', { value: this.id, text: this.name }).appendTo(uopt);
                    }
                });
            }
        }



        taxopt = '<p style="margin: 12px 0 0 0;">n/a</p>';
            if (site.settings.isOpen_invoice == 1) {


                taxopt = $('<select id="ptax_method" name="ptax_method" class="form-control select" />');


                if (item.row.tax_method==1) {
                    $('<option />', { value: 1, text: lang.exclusive, selected: true }).appendTo(taxopt);
                    $('<option />', { value: 0, text: lang.inclusive }).appendTo(taxopt);
                } else {
                    $('<option />', { value: 1, text: lang.exclusive }).appendTo(taxopt);
                    $('<option />', { value: 0, text: lang.inclusive, selected: true }).appendTo(taxopt);
                }



            }
            $('#poptions-div').html(opt);
            $('#punits-div').html(uopt);
            $('#ptax_method-div').html(taxopt);
            $('select.select').select2({ minimumResultsForSearch: 7 });
            $('#pquantity').val(qty);
            $('#old_qty').val(qty);
            $('#pprice').val(unit_price);

            $('#punit_price').val(formatDecimal(parseFloat(unit_price) + parseFloat(pr_tax_val),12));
            $('#poption').select2('val', item.row.option);
            $('#old_price').val(unit_price);
            $('#row_id').val(row_id);
            $('#item_id').val(item_id);
            $('#pserial').val(
                row
                    .children()
                    .children('.rserial')
                    .val()
            );

            $('#pdiscount').val(discount);
            $('#padiscount').val('');
            $('#psubt').val(row.find('.ssubtotal').text());
            if(item.row.lcprice>0){
                $('#lcprice').val(parseFloat(item.row.lcprice));
            }
            $('#net_price').text(formatMoney(net_price,localStorage.getItem('slcurrency')));
            $('#pro_tax').text(formatMoney(pr_tax_val,localStorage.getItem('slcurrency')));
            $('#prModal')
                .appendTo('body')
                .modal('show');
        });

        $('#prModal').on('shown.bs.modal', function(e) {
            if ($('#poption').select2('val') != '') {
                $('#poption').select2('val', product_variant);
                product_variant = 0;
            }
        });

        $(document).on('change', '#pprice, #ptax, #pdiscount, #ptax_method', function() {
            var row = $('#' + $('#row_id').val());
            var item_id = row.attr('data-item-id');
            var unit_price = parseFloat($('#pprice').val());

            var item_qty = parseFloat($('#pquantity').val());
            var item = slitems[item_id];

            var ds = $('#pdiscount').val() ? $('#pdiscount').val() : '0';
            if (site.settings.isOpen_invoice == 1 && typeof($('#ptax_method').val())  !== "undefined") {
                item.row.tax_method=$('#ptax_method').val();
            }


            var pr_tax = $('#ptax').val(),
                item_tax_method = item.row.tax_method;
            var pr_tax_val = 0,
                pr_tax_rate = 0;
            if (pr_tax !== null && pr_tax != 0) {
                $.each(tax_rates, function() {
                    if (this.id == pr_tax) {
                        if (this.type == 1) {

                            if (item_tax_method == 0) {
                                pr_tax_val = formatDecimal((unit_price * parseFloat(this.rate)) / (100 + parseFloat(this.rate)), 12);
                                //pr_tax_val = formatDecimal((unit_price * parseFloat(this.rate)) / (100 ), 12);
                                pr_tax_rate = formatDecimal(this.rate,12) + '%';
                                unit_price -= pr_tax_val;
                            } else {
                                pr_tax_val = formatDecimal((unit_price * parseFloat(this.rate)) / 100, 12);
                                pr_tax_rate = formatDecimal(this.rate,12) + '%';
                            }
                        } else if (this.type == 2) {
                            pr_tax_val = parseFloat(this.rate);
                            pr_tax_rate = this.rate;
                        }
                    }
                });
            }



            if (ds.indexOf('%') !== -1) {
                var pds = ds.split('%');
                if (!isNaN(pds[0])) {
                    item_discount = parseFloat((unit_price * parseFloat(pds[0])) / 100);
                } else {
                    item_discount = parseFloat(ds);
                }
            } else {
                item_discount = parseFloat(ds);
            }

            unit_price -= item_discount;


            $('#net_price').text(formatMoney(unit_price,localStorage.getItem('slcurrency')));
            $('#pro_tax').text(formatMoney(pr_tax_val,localStorage.getItem('slcurrency')));
            $('#psubt').val(formatMoney(formatMoney((parseFloat(unit_price) + parseFloat(pr_tax_val)) * parseFloat(item_qty)),localStorage.getItem('slcurrency')));

        });

        $(document).on('change', '#punit', function() {
            var row = $('#' + $('#row_id').val());
            var item_id = row.attr('data-item-id');
            var item = slitems[item_id];
            if (!is_numeric($('#pquantity').val())) {
                $(this).val(old_row_qty);
                bootbox.alert(lang.unexpected_value);
                return;
            }
            var opt = $('#poption').val(),
                unit = $('#punit').val(),
                base_quantity = $('#pquantity').val(),
                aprice = 0;
            if (item.options !== false) {
                $.each(item.options, function() {
                    if (this.id == opt && this.price != 0 && this.price != '' && this.price != null) {
                        aprice = parseFloat(this.price);
                    }
                });
            }
            if (item.units && unit != slitems[item_id].row.base_unit) {
                $.each(item.units, function() {
                    if (this.id == unit) {
                        base_quantity = unitToBaseQty($('#pquantity').val(), this);
                        $('#pprice')
                            .val(formatDecimal(parseFloat(item.row.base_unit_price + aprice) * unitToBaseQty(1, this), 12))
                            .change();
                    }
                });
            } else {
                $('#pprice')
                    .val(formatDecimal(item.row.base_unit_price + aprice,12))
                    .change();
            }
        });

        /* -----------------------
         * Edit Row Method
         ----------------------- */
        $(document).on('click', '#editItem', function() {
            var row = $('#' + $('#row_id').val());
            var item_id = row.attr('data-item-id'),
                new_pr_tax = $('#ptax').val(),
                new_pr_tax_rate = false;
            if (new_pr_tax) {
                $.each(tax_rates, function() {
                    if (this.id == new_pr_tax) {
                        new_pr_tax_rate = this;
                    }
                });
            }
            var price = parseFloat($('#pprice').val());


            var unit = $('#punit').val();
            var base_quantity = parseFloat($('#pquantity').val());
            if (unit != slitems[item_id].row.base_unit) {
                $.each(slitems[item_id].units, function() {
                    if (this.id == unit) {
                        base_quantity = unitToBaseQty($('#pquantity').val(), this);
                    }
                });
            }else{
                if(parseFloat(item.row.minimum_selling_price) > price){
                    bootbox.alert(lang.Exceeded_the_minimum_selling_price);
                        return false;
                }
            }

            if(slitems[item_id].row.base_unit!=null){}else{
                if(parseFloat(item.row.minimum_selling_price) > price){
                    bootbox.alert(lang.Exceeded_the_minimum_selling_price);
                        return false;
                }
            }
            if (item.options !== false) {
                var opt = $('#poption').val();
                $.each(item.options, function() {
                    if (this.id == opt && this.price != 0 && this.price != '' && this.price != null) {
                        price = price - parseFloat(this.price);
                        // price = price - parseFloat(this.price) * parseFloat(base_quantity);
                    }
                });
            }
            if (site.settings.product_discount == 1 && $('#pdiscount').val()) {
                if (!is_valid_discount($('#pdiscount').val()) || ($('#pdiscount').val() != 0 && $('#pdiscount').val() > price)) {
                    bootbox.alert(lang.unexpected_value);
                    return false;
                }
            }
            var discount = $('#pdiscount').val() ? $('#pdiscount').val() : '';
            if (!is_numeric($('#pquantity').val())) {
                $(this).val(old_row_qty);
                bootbox.alert(lang.unexpected_value);
                return;
            }
            var quantity = parseFloat($('#pquantity').val());
            // if (site.settings.product_discount == 1 && $('#padiscount').val()) {
            //     if (!is_numeric($('#padiscount').val()) || $('#padiscount').val() > price * quantity) {
            //         bootbox.alert(lang.unexpected_value);
            //         return false;
            //     }
            //     discount = formatDecimal(parseFloat($('#padiscount').val()) / quantity, 12);
            // }
            // console.log(discount);

            slitems[item_id].row.fup = 1;
            slitems[item_id].row.qty = quantity;
            slitems[item_id].row.base_quantity = parseFloat(base_quantity);



            slitems[item_id].row.real_unit_price = price;
            slitems[item_id].row.unit = unit;
            slitems[item_id].row.tax_rate = new_pr_tax;
            slitems[item_id].tax_rate = new_pr_tax_rate;
            slitems[item_id].row.discount = discount;
            slitems[item_id].row.option = $('#poption').val() ? $('#poption').val() : '';
            slitems[item_id].row.serial = $('#pserial').val();
            localStorage.setItem('slitems', JSON.stringify(slitems));
            $('#prModal').modal('hide');

            loadItems();
            return;
        });
        $(document).on('change', '#padiscount', function() {
            if (site.settings.product_discount == 1 && $(this).val()) {
                var row = $('#' + $('#row_id').val());
                var item_id = row.attr('data-item-id'),
                    new_pr_tax = $('#ptax').val(),
                    new_pr_tax_rate = false;
                var item = slitems[item_id];
                if (new_pr_tax) {
                    $.each(tax_rates, function() {
                        if (this.id == new_pr_tax) {
                            new_pr_tax_rate = this;
                        }
                    });
                }
                var quantity = parseFloat($('#pquantity').val());
                var price = parseFloat($('#pprice').val());
                var pr_tax = new_pr_tax_rate;
                var pr_tax_val = 0,
                    pr_tax_rate = 0;
                var total_tax = 0;
                if (site.settings.tax1 == 1) {
                    if (pr_tax !== false && pr_tax != 0 && pr_tax.rate != 0) {
                        if (pr_tax.type == 1) {
                            if (item.row.tax_method == 0) {
                                pr_tax_val = formatDecimal((price * parseFloat(pr_tax.rate)) / (100 + parseFloat(pr_tax.rate)), 12);
                                //pr_tax_val = formatDecimal((price * parseFloat(pr_tax.rate)) / (100 ), 12);
                                price = formatDecimal(price - parseFloat(pr_tax_val), 12);
                            } else {
                                pr_tax_val = formatDecimal((price * parseFloat(pr_tax.rate)) / 100, 12);
                                price = formatDecimal(price + parseFloat(pr_tax_val), 12);
                            }
                        } else if (pr_tax.type == 2) {
                            price =
                                item.row.tax_method == 0
                                    ? formatDecimal(price - parseFloat(pr_tax.rate), 12)
                                    : formatDecimal(price + parseFloat(pr_tax.rate), 12);
                        }
                    }
                }


                var total = formatDecimal((price + parseFloat(pr_tax_val)) * quantity, 12);
                var expected_total = parseFloat($(this).val());
                var expected_discount = formatDecimal(((total - expected_total) / total) * 100, 12);
                $('#pdiscount').val(expected_discount + '%');
            }
        });

        /* -----------------------
         * Product option change
         ----------------------- */
        $(document).on('change', '#poption', function() {
            var row = $('#' + $('#row_id').val()),
                opt = $(this).val();
            var item_id = row.attr('data-item-id');
            var item = slitems[item_id];
            var unit = $('#punit').val(),
                base_quantity = parseFloat($('#pquantity').val()),
                base_unit_price = item.row.base_unit_price;
            if (unit != slitems[item_id].row.base_unit) {
                $.each(slitems[item_id].units, function() {
                    if (this.id == unit) {
                        base_unit_price = formatDecimal(parseFloat(item.row.base_unit_price) * unitToBaseQty(1, this), 12);
                        base_quantity = unitToBaseQty($('#pquantity').val(), this);
                    }
                });
            }
            $('#pprice')
                .val(parseFloat(base_unit_price))
                .trigger('change');
            if (item.options !== false) {
                $.each(item.options, function() {
                    if (this.id == opt && this.price != 0 && this.price != '' && this.price != null) {
                        $('#pprice')
                            .val(parseFloat(base_unit_price) + parseFloat(this.price))
                            .trigger('change');
                        // .val(parseFloat(base_unit_price) + parseFloat(this.price) * parseFloat(base_quantity))
                    }
                });
            }
        });

        /* ------------------------------
         * Sell Gift Card modal
         ------------------------------- */
        $(document).on('click', '#sellGiftCard', function(e) {
            if (count == 1) {
                slitems = {};
                if ($('#slwarehouse').val() && $('#slcustomer').val()) {
                    $('#slcustomer').select2('readonly', true);
                    $('#slwarehouse').select2('readonly', true);
                    $('#grpId').select2('readonly', true);
                    $('#coId').select2('readonly', true);
                    $('#brId').select2('readonly', true);
                } else {

                    if($('#slwarehouse').val()){
                        bootbox.alert(lang.Select_warehouse);
                    }else if($('#slcustomer').val()){
                        bootbox.alert(lang.Select_customer);
                    }


                    item = null;
                    return false;
                }
            }
            $('#gcModal')
                .appendTo('body')
                .modal('show');
            return false;
        });

        $(document).on('click', '#addGiftCard', function(e) {
            var mid = new Date().getTime(),
                gccode = $('#gccard_no').val(),
                gcname = $('#gcname').val(),
                gcvalue = $('#gcvalue').val(),
                gccustomer = $('#gccustomer').val(),
                gcexpiry = $('#gcexpiry').val() ? $('#gcexpiry').val() : '',
                gcprice = parseFloat($('#gcprice').val());
            if (gccode == '' || gcvalue == '' || gcprice == '' || gcvalue == 0 || gcprice == 0) {
                $('#gcerror').text('Please fill the required fields');
                $('.gcerror-con').show();
                return false;
            }

            var gc_data = new Array();
            gc_data[0] = gccode;
            gc_data[1] = gcvalue;
            gc_data[2] = gccustomer;
            gc_data[3] = gcexpiry;
            //if (typeof slitems === "undefined") {
            //    var slitems = {};
            //}

            $.ajax({
                type: 'get',
                url: site.base_url + 'sales/sell_gift_card',
                dataType: 'json',
                data: { gcdata: gc_data },
                success: function(data) {
                    if (data.result === 'success') {
                        slitems[mid] = {
                            id: mid,
                            item_id: mid,
                            label: gcname + ' (' + gccode + ')',
                            row: {
                                id: mid,
                                code: gccode,
                                name: gcname,
                                quantity: 1,
                                base_quantity: 1,
                                price: gcprice,
                                real_unit_price: gcprice,
                                tax_rate: 0,
                                qty: 1,
                                type: 'manual',
                                discount: '0',
                                serial: '',
                                option: '',
                            },
                            tax_rate: false,
                            options: false,
                            units: false,
                        };
                        localStorage.setItem('slitems', JSON.stringify(slitems));
                        loadItems();
                        $('#gcModal').modal('hide');
                        $('#gccard_no').val('');
                        $('#gcvalue').val('');
                        $('#gcexpiry').val('');
                        $('#gcprice').val('');
                    } else {
                        $('#gcerror').text(data.message);
                        $('.gcerror-con').show();
                    }
                },
            });
            return false;
        });

        /* ------------------------------
         * Show manual item addition modal
         ------------------------------- */
        /*$(document).on('click', '#addManually', function(e) {
            if (count == 1) {
                slitems = {};
                if ($('#slwarehouse').val() && $('#slcustomer').val()) {
                    $('#slcustomer').select2('readonly', true);
                    $('#slwarehouse').select2('readonly', true);
                } else {
                    bootbox.alert(lang.select_above);
                    item = null;
                    return false;
                }
            }
            $('#mnet_price').text('0.00');
            $('#mpro_tax').text('0.00');
            $('#mModal')
                .appendTo('body')
                .modal('show');
            return false;
        });

        $(document).on('click', '#addItemManually', function(e) {
            var mid = new Date().getTime(),
                mcode = $('#mcode').val(),
                mname = $('#mname').val(),
                mtax = parseInt($('#mtax').val()),
                munit = parseInt($('#munit').val()),
                mqty = parseFloat($('#mquantity').val()),
                mdiscount = $('#mdiscount').val() ? $('#mdiscount').val() : '0',
                unit_price = parseFloat($('#mprice').val()),
                mtax_rate = {};
            if (mcode && mname && mqty && unit_price) {
                $.each(tax_rates, function() {
                    if (this.id == mtax) {
                        mtax_rate = this;
                    }
                });

                slitems[mid] = {
                    id: mid,
                    item_id: mid,
                    label: mname + ' (' + mcode + ')',
                    row: {
                        id: mid,
                        code: mcode,
                        name: mname,
                        quantity: mqty,
                        base_quantity: mqty,
                        price: unit_price,
                        unit_price: unit_price,
                        real_unit_price: unit_price,
                        tax_rate: mtax,
                        unit: munit,
                        tax_method: 0,
                        qty: mqty,
                        type: 'manual',
                        discount: mdiscount,
                        serial: '',
                        option: '',
                    },
                    tax_rate: mtax_rate,
                    units: false,
                    options: false,
                };
                localStorage.setItem('slitems', JSON.stringify(slitems));
                loadItems();
            }
            $('#mModal').modal('hide');
            $('#mcode').val('');
            $('#mname').val('');
            $('#mtax').val('');
            $('#munit').val('');
            $('#mquantity').val('');
            $('#mdiscount').val('');
            $('#mprice').val('');
            return false;
        });*/

        $(document).on('change', '#mprice, #mtax, #mdiscount', function() {
            //alert('');
            var unit_price = parseFloat($('#mprice').val());
            var ds = $('#mdiscount').val() ? $('#mdiscount').val() : '0';
            if (ds.indexOf('%') !== -1) {
                var pds = ds.split('%');
                if (!isNaN(pds[0])) {
                    item_discount = parseFloat((unit_price * parseFloat(pds[0])) / 100);
                } else {
                    item_discount = parseFloat(ds);
                }
            } else {
                item_discount = parseFloat(ds);
            }
            unit_price -= item_discount;
            var pr_tax = $('#mtax').val(),
                item_tax_method = 0;
            var pr_tax_val = 0,
                pr_tax_rate = 0;
            if (pr_tax !== null && pr_tax != 0) {
                $.each(tax_rates, function() {
                    if (this.id == pr_tax) {
                        if (this.type == 1) {
                            if (item_tax_method == 0) {
                                pr_tax_val = formatDecimal((unit_price * parseFloat(this.rate)) / (100 + parseFloat(this.rate)), 12);
                                //pr_tax_val = formatDecimal((unit_price * parseFloat(this.rate)) / (100), 12);
                                pr_tax_rate = formatDecimal(this.rate,12) + '%';
                                unit_price -= pr_tax_val;
                            } else {
                                pr_tax_val = formatDecimal((unit_price * parseFloat(this.rate)) / 100, 12);
                                pr_tax_rate = formatDecimal(this.rate,12) + '%';
                            }
                        } else if (this.type == 2) {
                            pr_tax_val = parseFloat(this.rate);
                            pr_tax_rate = this.rate;
                        }
                    }
                });
            }

            $('#mnet_price').text(formatMoney(unit_price,12));
            $('#mpro_tax').text(formatMoney(pr_tax_val,12));
        });

        /* --------------------------
         * Edit Row Quantity Method
        --------------------------- */
        var old_row_qty;
        $(document)
            .on('focus', '.rquantity', function() {
                old_row_qty = $(this).val();
            })
            .on('change', '.rquantity', function() {
                var row = $(this).closest('tr');

                if (!is_numeric($(this).val())) {
                    $(this).val(old_row_qty);
                    bootbox.alert(lang.unexpected_value);
                    return;
                }

                var new_qty = parseFloat($(this).val()),
                    item_id = row.attr('data-item-id');

                slitems[item_id].row.base_quantity = new_qty;
                if (slitems[item_id].row.unit != slitems[item_id].row.base_unit) {
                    $.each(slitems[item_id].units, function() {
                        if (this.id == slitems[item_id].row.unit) {
                            slitems[item_id].row.base_quantity = unitToBaseQty(new_qty, this);
                        }
                    });
                }
                slitems[item_id].row.qty = new_qty;
                localStorage.setItem('slitems', JSON.stringify(slitems));


                var wh = $("#slwarehouse").val();


                $.ajax({
                    type: "get",
                    url: site.base_url + 'sales/getProductPromoRDiscountWithQty',

                    data: {product_id: item_id, warehouse_id: wh, item_quantity: slitems[item_id].row.qty},
                    dataType: "json",
                    success: function (data) {
                        if (data) {
                            slitems[item_id].row.discount=data.discount;
                            //console.log(slitems[item_id].row.discount);
                            localStorage.setItem('slitems', JSON.stringify(slitems));
                            loadItems();
                        }
                        $("#add_item").removeClass('ui-autocomplete-loading');
                    }
                }).done(function () {
                    $('#modal-loading').hide();
                });


                        $.ajax({
                            type: "get",
                            url: site.base_url + 'sales/getProductPromoRquantity',

                            data: {product_id: item_id, warehouse_id: wh, item_quantity: slitems[item_id].row.qty},
                            dataType: "json",
                            success: function (data) {
                                if (data) {
                                    data.free = true;
                                    data.parent = slitems[item_id].row.id;
                                    if(slitems[data.row.id]){
                                        var row = $('.row_'+data.row.id).closest('tr');
                                        //alert()

                                        //var item_id = row.attr('data-item-id');
                                        var new_qty = parseFloat(data.row.qty);


                                        row.find('.rquantity').val(data.row.qty)


                                        slitems[data.row.id].row.base_quantity = new_qty;
                if (slitems[data.row.id].row.unit != slitems[data.row.id].row.base_unit) {
                    $.each(slitems[data.row.id].units, function() {
                        if (this.id == slitems[data.row.id].row.unit) {
                            slitems[data.row.id].row.base_quantity = unitToBaseQty(new_qty, this);
                        }
                    });
                }

                                   slitems[data.row.id].row.qty=new_qty;


                                   slitems[data.row.id].order = new Date().getTime();

                                   localStorage.setItem('slitems', JSON.stringify(slitems));
                                    }else
                                    add_invoice_item(data);
                                }
                                $("#add_item").removeClass('ui-autocomplete-loading');
                            }
                        }).done(function () {
                            $('#modal-loading').hide();
                        });


                loadItems();
            });

            var old_row_area;
        $(document)
            .on('focus', '.rarea', function() {
                old_row_area = $(this).val();
            })
            .on('change', '.rarea', function() {
                var row = $(this).closest('tr');

                if (!is_numeric($(this).val())) {
                    $(this).val(old_row_area);
                    bootbox.alert(lang.unexpected_value);
                    return;
                }

                var new_area = parseFloat($(this).val()),
                    item_id = row.attr('data-item-id');


                slitems[item_id].row.area = new_area;
                localStorage.setItem('slitems', JSON.stringify(slitems));





                loadItems();
            });

        /* --------------------------
         * Edit Row Price Method
         -------------------------- */
        var old_name;
        $(document)
            .on('focus', '.rname', function() {
                old_name = $(this).val();
            })
            .on('change', '.rname', function() {
                var row = $(this).closest('tr');

                var new_name = ($(this).val()),
                    item_id = row.attr('data-item-id');
                slitems[item_id].row.name = new_name;
                localStorage.setItem('slitems', JSON.stringify(slitems));
                loadItems(1);
            });


            var old_code;
        $(document)
            .on('focus', '.rcode', function() {
                old_code = $(this).val();
            })
            .on('change', '.rcode', function() {
                var row = $(this).closest('tr');

                var new_code = ($(this).val()),
                    item_id = row.attr('data-item-id');
                slitems[item_id].row.code = new_code;
                localStorage.setItem('slitems', JSON.stringify(slitems));
                loadItems(1);
            });





         var old_price;
        $(document)
            .on('focus', '.rprice', function() {
                old_price = $(this).val();
            })
            .on('change', '.rprice', function() {
                var row = $(this).closest('tr');
                if (!is_numeric($(this).val())) {
                    $(this).val(old_price);
                    bootbox.alert(lang.unexpected_value);
                    return;
                }
                var new_price = parseFloat($(this).val()),
                    item_id = row.attr('data-item-id');
                slitems[item_id].row.price = new_price;
                localStorage.setItem('slitems', JSON.stringify(slitems));
                loadItems();
            });

        $(document).on('click', '#removeReadonly', function() {
            $('#slcustomer').select2('readonly', false);
            //$('#slwarehouse').select2('readonly', false);
            return false;
        });
    });
    /* -----------------------
     * Misc Actions
     ----------------------- */
    //url: site.base_url + 'customers/suggestions/' + localStorage.getItem('sgrpId')+'/' + localStorage.getItem('scoId')+'/' + localStorage.getItem('sbrId'),

    // hellper function for customer if no localStorage value
    function nsCustomer() {
        $('#slcustomer').select2({
            minimumInputLength: 1,
            ajax: {
                url: site.base_url + 'customers/suggestions',
                dataType: 'json',
                quietMillis: 15,
                data: function(term, page) {
                    return {
                        term: term,
                        limit: 10,
                        grpId: localStorage.getItem('sgrpId'),
                        coId: localStorage.getItem('scoId'),
                        brId: localStorage.getItem('sbrId'),

                    };
                },
                results: function(data, page) {
                    //if (localStorage.getItem('sgrpId') && localStorage.getItem('scoId') && localStorage.getItem('sbrId')) {

                    if (data.results != null) {
                        return { results: data.results };
                    } else {
                        return { results: [{ id: '', text: 'No Match Found' }] };
                    }
                /*}else{
                    bootbox.alert(lang.select_above);
                    return { results: [{ id: '', text: 'No Match Found' }] };
                }*/
                },
            },
        });
    }
    //localStorage.clear();
    function loadItems(openInv) {


        if (localStorage.getItem('slitems')) {


            try{
            $.ajax({
                    type: 'get',
                    async: false,
                    url: site.base_url + 'sales/getCurrencyByCode/' + $('#slcurrency').val(),
                    dataType: 'json',
                    data: { code : $('#slcurrency').val()},
                    success: function(data, page) {
                        //data.co_type
                        //alert(data.rate);
                        currRate=data.rate;
                    },
                });

            }catch(err){alert(err);}


            //alert(currRate);



            var gdiscounttotal=getDiscount();

            total = 0;
            count = 1;
            an = 1;
            product_tax = 0;
            invoice_tax = 0;
            product_discount = 0;
            order_discount = 0;
            total_discount = 0;

            $('#slTable tbody').empty();
            slitems = JSON.parse(localStorage.getItem('slitems'));
            sortedItems =
                site.settings.item_addition == 1
                    ? _.sortBy(slitems, function(o) {
                          return [parseInt(o.order)];
                      })
                    : slitems;

            if(sortedItems.length!=0)
                $('#add_sale, #edit_sale').attr('disabled', false);
            $.each(sortedItems, function() {
                var item = this;
                var item_id = site.settings.item_addition == 1 ? item.item_id : item.id;
                if(item.unit_first!=null)
                item_id=item.id;
                item.order = item.order ? item.order : new Date().getTime();
                var product_id = item.row.id,
                    item_type = item.row.type,
                    combo_items = item.combo_items,
                    item_price = item.row.price,
                    item_area = item.row.area,
                    item_qty = item.row.qty,
                    item_aqty = item.row.quantity,
                    item_tax_method = item.row.tax_method,
                    item_ds = item.row.discount,
                    item_discount = 0,
                    item_option = item.row.option,
                    item_code = item.row.code,
                    item_serial = item.row.serial,
                    item_name = item.row.name.replace(/"/g, '&#034;').replace(/'/g, '&#039;');
                var product_unit = item.row.unit,
                    base_quantity = item.row.base_quantity;
                var unit_price = item.row.real_unit_price;
                if (item.units && item.row.fup != 1 && product_unit != item.row.base_unit) {
                    $.each(item.units, function() {
                        if (this.id == product_unit) {
                            base_quantity = formatDecimal(unitToBaseQty(item.row.qty, this), 12);

                            //unit_price = formatDecimal(parseFloat(item.row.base_unit_price) * unitToBaseQty(1, this), 12);

                        }
                    });
                }

                var sel_opt = '';
                if (item.options !== false) {
                    $.each(item.options, function() {
                        if (this.id == item_option) {
                            sel_opt = this.name;
                            if (this.price != 0 && this.price != '' && this.price != null) {
                                // item_price = unit_price + parseFloat(this.price) * parseFloat(base_quantity);
                                item_price = formatDecimal(parseFloat(unit_price) + parseFloat(this.price),12);
                                unit_price = item_price;
                            }
                        }
                    });
                }




                //if(item_ds==0){

                var pr_tax = item.tax_rate;
                //if(!isset(old_item_tax))
                old_item_tax=pr_tax.id;

                var pr_tax_val = 0,
                    pr_tax_rate = 0;
                if (site.settings.tax1 == 1) {
                    if (pr_tax !== false && pr_tax != 0) {
                        if (pr_tax.type == 1) {

                            if (item_tax_method == '0') {
                                pr_tax_val = formatDecimal((unit_price * parseFloat(pr_tax.rate)) / (100 + parseFloat(pr_tax.rate)), 12);
                                //pr_tax_val = formatDecimal((unit_price * formatDecimal(pr_tax.rate,12)) / (100), 12);
                                pr_tax_rate = formatDecimal(pr_tax.rate,12) + '%';
                            } else {
                                pr_tax_val = formatDecimal((unit_price * formatDecimal(pr_tax.rate,12)) / 100, 12);

                                pr_tax_rate = formatDecimal(pr_tax.rate,12) + '%';
                            }
                        } else if (pr_tax.type == 2) {
                            pr_tax_val = parseFloat(pr_tax.rate);
                            pr_tax_rate = pr_tax.rate;
                        }
                        //product_tax += pr_tax_val * item_qty;
                    }
                }
               unit_price = item_tax_method == 0 ? formatDecimal(unit_price - pr_tax_val, 12) : formatDecimal(unit_price,12);




                if (site.settings.IsCurtains == 1 || site.settings.IsEquipmentRental == 1)
                unit_price=unit_price*item_area;


                var ds = item_ds ? item_ds : '0';
                if (ds.indexOf('%') !== -1) {
                    var pds = ds.split('%');
                    if (!isNaN(pds[0])) {
                        item_discount = formatDecimal((unit_price * parseFloat(pds[0])) / 100, 12);
                    } else {
                        item_discount = formatDecimal(ds,12);
                    }
                } else {
                    item_discount = formatDecimal(ds,12);
                }


                product_discount += formatDecimal(item_discount * item_qty, 12);


                isTobacco=0;
                if (site.settings.isTobacco == 1){
                try{
                 $.ajax({
                         type: 'get',
                         async: false,
                         url: site.base_url + 'products/getCategoryById/' + item.row.category_id,
                         dataType: 'json',
                         data: { id : item.row.category_id},
                         success: function(data, page) {

                             if (data.isTobacco == 1) {
                                 isTobacco=1;


                             }else{
                                 isTobacco=0;
                             }

                         },
                     });

                 }catch(err){alert(err);}
             }



                if($('#tax_method_type').val()==1){
                    if ((sldiscount = localStorage.getItem('sldiscount'))) {
                var ds = sldiscount;
                if (ds.indexOf('%') !== -1) {
                    var pds = ds.split('%');
                    if (!isNaN(pds[0])) {
                        /*if (item_tax_method == '0')
                        order_discount = formatDecimal(((unit_price+ pr_tax_val)*item_qty * parseFloat(pds[0])) / 100, 12);
                    else*/
                        order_discount = formatDecimal(((unit_price)*item_qty * parseFloat(pds[0])) / 100, 12);

                        //alert(order_discount);
                    } else {
                        order_discount = formatDecimal(ds,12);
                    }

                    if(isTobacco==1)
                        unit_price=unit_price*2;
                } else {
                //    order_discount = formatDecimal(((unit_price*item_qty)/gdiscounttotal)*ds);
                if(isTobacco==1)
                    unit_price=unit_price*2;

                    order_discount = formatDecimal(((unit_price*item_qty)/gdiscounttotal)*ds,12);
                    //alert(order_discount);
                }

                //total_discount += parseFloat(order_discount);
            }

            //alert(unit_price);
            //alert(item_qty);
            //alert(gdiscounttotal);
             order_discount=formatDecimal(order_discount/item_qty,12);
            //alert(unit_price);
              item_discount=order_discount;


            //slitems[item_id].row.discount = discount;
                //localStorage.setItem('slitems', JSON.stringify(slitems));

            //$('#pdiscount').val(item_discount).trigger('change');

            //product_discount += formatDecimal(item_discount * item_qty, 12);




                }else{
                    if(isTobacco==1)
                        unit_price=unit_price*2;
                }


                //if(isTobacco==1)
                //unit_price=unit_price*2;

                //if(item_tax_method == 0)
                unit_price = formatDecimal((unit_price - item_discount),12);

                item_price = item_tax_method == 0 ? formatDecimal(unit_price, 12) : formatDecimal(unit_price,12);






                //alert(unit_price);
                //item_price = item_tax_method == 0 ? formatDecimal(unit_price - pr_tax_val, 12) : formatDecimal(unit_price,12);
                 if(item_tax_method == 0)
                unit_price = formatDecimal(unit_price + item_discount , 12);






                 pr_tax = item.tax_rate;
                //if(!isset(old_item_tax))
                old_item_tax=pr_tax.id;
                 pr_tax_val = 0,
                    pr_tax_rate = 0;
                if (site.settings.tax1 == 1) {
                    if (pr_tax !== false && pr_tax != 0) {
                        if (pr_tax.type == 1) {

                            if (item_tax_method == '0') {
                                //pr_tax_val = formatDecimal((item_price * parseFloat(pr_tax.rate)) / (100 + parseFloat(pr_tax.rate)), 12);
                                pr_tax_val = formatDecimal((item_price * formatDecimal(pr_tax.rate,12)) / (100), 12);
                                pr_tax_rate = formatDecimal(pr_tax.rate,12) + '%';
                            } else {
                                pr_tax_val = formatDecimal((item_price * formatDecimal(pr_tax.rate,12)) / 100, 12);

                                pr_tax_rate = formatDecimal(pr_tax.rate,12) + '%';
                            }
                        } else if (pr_tax.type == 2) {
                            pr_tax_val = parseFloat(pr_tax.rate);
                            pr_tax_rate = pr_tax.rate;
                        }
                        product_tax += pr_tax_val * item_qty;
                    }
                }

                var item_code_first=item_code;
                if(item.code_first!=null)
                    item_code_first=item.code_first;

                var row_no = item.id;
                var newTr = $('<tr id="row_' + row_no + '" class="row_' + item_id + '" data-item-id="' + item_id + '"></tr>');

                if (item.row.code == 'sub_qty') {

                    tr_html =
                        '<td colspan="9" class="text-center">' +
                        '<input name="product_code[]" type="hidden" value="sub_qty">Sub Quantity</td>' +
                        '<input name="product_id[]" type="hidden" class="rid" value="">' +
                        '<input name="product_name[]" type="hidden" class="rid" value="">' +
                        '<input name="product_type[]" type="hidden" class="rid" value="">' +
                        '<input name="product_option[]" type="hidden" class="rid" value="">' +
                        '<input name="product_comment[]" type="hidden" class="rid" value="">' +
                        '<input name="serial[]" type="hidden" class="rid" value="">' +
                        '<input name="product_discount[]" type="hidden" class="rid" value="">' +
                        '<input name="product_tax[]" type="hidden" class="rid" value="">' +
                        '<input name="net_price[]" type="hidden" class="rid" value="">' +
                        '<input name="unit_price[]" type="hidden" class="rid" value="">' +
                        '<input name="real_unit_price[]" type="hidden" class="rid" value="">' +
                        '<input name="quantity[]" type="hidden" class="rid" value="">' +
                        '<input name="product_unit[]" type="hidden" class="rid" value="">' +
                        '<input name="product_base_quantity[]" type="hidden" class="rid" value="">';
                    newTr.html(tr_html);
                    newTr.prependTo('#slTable');
                } else {

                    if(openInv==1){



                            tr_html =
                        '<td><input name="product_id[]" type="hidden" class="rid" value="' +
                        product_id +
                        '"><input name="product_type[]" type="hidden" class="rtype" value="' +
                        item_type +
                        '"><input name="product_code[]" type="text" class="rcode" style="margin:5px;height:34px;" placeholder="Code" value="' +
                        item_code +
                        '"><input name="product_name[]" type="text" class="rname" style="margin:5px;height:34px;" placeholder="Description" value="' +
                        item_name +
                        '"><input name="product_option[]" type="hidden" class="roption" value="' +
                        item_option +
                        '"> <i class="pull-right fa fa-edit tip pointer edit" id="' +
                        row_no +
                        '" data-item="' +
                        item_id +
                        '" title="Edit" style="cursor:pointer;"></i></td>';

                        }else if($('#tax_method_type').val()!=1)
                    {


                    tr_html =
                        '<td><input name="product_id[]" type="hidden" class="rid" value="' +
                        product_id +
                        '"><input name="product_type[]" type="hidden" class="rtype" value="' +
                        item_type +
                        '"><input name="product_code[]" type="hidden" class="rcode" value="' +
                        item_code +
                        '"><input name="product_name[]" type="hidden" class="rname" value="' +
                        item_name +
                        '"><input name="product_option[]" type="hidden" class="roption" value="' +
                        item_option +
                        '"><span class="sname" id="name_' +
                        row_no +
                        '">' +
                        item_code_first +
                        ' - ' +
                        item_name +
                        (sel_opt != '' ? ' (' + sel_opt + ')' : '') +
                        '</span> <i class="pull-right fa fa-edit tip pointer edit" id="' +
                        row_no +
                        '" data-item="' +
                        item_id +
                        '" title="Edit" style="cursor:pointer;"></i></td>';

                    }else{
                    tr_html =
                        '<td><input name="product_id[]" type="hidden" class="rid" value="' +
                        product_id +
                        '"><input name="product_type[]" type="hidden" class="rtype" value="' +
                        item_type +
                        '"><input name="product_code[]" type="hidden" class="rcode" value="' +
                        item_code +
                        '"><input name="product_name[]" type="hidden" class="rname" value="' +
                        item_name +
                        '"><input name="product_option[]" type="hidden" class="roption" value="' +
                        item_option +
                        '"><span class="sname" id="name_' +
                        row_no +
                        '">' +
                        item_code_first +
                        ' - ' +
                        item_name +
                        (sel_opt != '' ? ' (' + sel_opt + ')' : '') +
                        '</span> </td>';
                    }
                    /*if (site.settings.product_serial == 1) {
                        tr_html +=
                            '<td class="text-right"><input class="form-control input-sm rserial" name="serial[]" type="text" id="serial_' +
                            row_no +
                            '" value="' +
                            item_serial +
                            '"></td>';
                    }*/



                    tr_html +=
                        '<td class="text-right"><span class="text-right sprice" id="sprice_' +
                        row_no +
                        '">' +
                        formatMoney(item.row.real_unit_price,localStorage.getItem('slcurrency')) +
                        '</span></td>';

                    tr_html +=
                        '<td class="text-right"><input class="form-control input-sm text-right rprice" name="net_price[]" type="hidden" id="price_' +
                        row_no +
                        '" value="' +
                        formatDecimal(item_price, 12) +
                        '"><input class="ruprice" name="unit_price[]" type="hidden" value="' +
                        unit_price +
                        '"><input class="realuprice" name="real_unit_price[]" type="hidden" value="' +
                        item.row.real_unit_price +
                        '"><span class="text-right sprice" id="sprice_' +
                        row_no +
                        '">' +
                        formatMoney((item_price + item_discount),localStorage.getItem('slcurrency')) +
                        '</span></td>';

                        if (site.settings.IsCurtains == 1 || site.settings.IsEquipmentRental == 1) {
                            tr_html +=
                        '<td><input class="form-control text-center rarea" name="area[]" type="text" value="' +
                        formatQuantity2(item_area) +
                        '" data-id="' +
                        row_no +
                        '" data-item="' +
                        item_id +
                        '" id="area_' +
                        row_no +
                        '" onClick="this.select();"></td>';
                        }

                        tr_html +=
                        '<td><input class="form-control text-center rquantity" tabindex="' +
                        (site.settings.set_focus == 1 ? an : an + 1) +
                        '" name="quantity[]" type="text" value="' +
                        formatQuantity2(item_qty) +
                        '" data-id="' +
                        row_no +
                        '" data-item="' +
                        item_id +
                        '" id="quantity_' +
                        row_no +
                        '" onClick="this.select();"><input name="product_unit[]" type="hidden" class="runit" value="' +
                        product_unit +
                        '"><input name="product_base_quantity[]" type="hidden" class="rbase_quantity" value="' +
                        base_quantity +
                        '"></td>';
                    if($('#tax_method_type').val()!=1){
                    if ((site.settings.product_discount == 1 && allow_discount == 1) || item_discount) {
                        tr_html +=
                            '<td class="text-right"><input class="form-control input-sm rdiscount" name="product_discount[]" type="hidden" id="discount_' +
                            row_no +
                            '" value="' +
                            item_ds +
                            '"><span class="text-right sdiscount text-danger" id="sdiscount_' +
                            row_no +
                            '">' +
                            formatMoney(item_discount * item_qty,localStorage.getItem('slcurrency')) +
                            '</span></td>';
                    }
                    }else{
                    if ((site.settings.product_discount == 1 && allow_discount == 1) || item_discount) {
                        tr_html +=
                            '<td class="text-right"><input class="form-control input-sm rdiscount" name="product_discount[]" type="hidden" id="discount_' +
                            row_no +
                            '" value="' +
                            item_ds +
                            '"><span class="text-right sdiscount text-danger" id="sdiscount_' +
                            row_no +
                            '">' +
                            formatMoney(item_discount * item_qty,localStorage.getItem('slcurrency')) +
                            '</span></td>';
                    }




                    }
                    //if($('#tax_method_type').val()!=1)
                    if (site.settings.tax1 == 1) {
                        tr_html +=
                            '<td class="text-right"><input class="form-control input-sm text-right rproduct_tax" name="product_tax[]" type="hidden" id="product_tax_' +
                            row_no +
                            '" value="' +
                            pr_tax.id +
                            '"><span class="text-right sproduct_tax" id="sproduct_tax_' +
                            row_no +
                            '">' +
                            (parseFloat(pr_tax_rate) != 0 ? '(' + formatDecimal(pr_tax_rate,12) + ')' : '') +
                            ' ' +
                            formatMoney(pr_tax_val * item_qty,localStorage.getItem('slcurrency')) +
                            '</span></td>';
                    }
                    tr_html +=
                        '<td class="text-right"><span class="text-right ssubtotal" id="subtotal_' +
                        row_no +
                        '">' +
                        formatMoney((parseFloat(item_price) + parseFloat(pr_tax_val)) * parseFloat(item_qty),localStorage.getItem('slcurrency')) +
                        '</span></td>';
                    tr_html +=
                        '<td class="text-center"><i class="fa fa-times tip pointer sldel" id="' +
                        row_no +
                        '" title="Remove" style="cursor:pointer;"></i></td>';
                    newTr.html(tr_html);
                    newTr.prependTo('#slTable');
                    total += formatDecimal((formatDecimal(item_price, 12) + formatDecimal(pr_tax_val, 12)) * formatDecimal(item_qty, 12), 12);
                    //alert(formatDecimal(item_price, 12) + formatDecimal(pr_tax_val, 12));
                    count += parseFloat(item_qty);
                    an++;
                }
                //alert(formatDecimal((formatDecimal(pr_tax_val, 12)) , 12));

                if (item_type == 'standard' && item.options !== false) {
                    $.each(item.options, function() {
                        if (this.id == item_option && base_quantity > this.quantity) {
                            $('#row_' + row_no).addClass('danger');
                            if (site.settings.overselling != 1) {
                                $('#add_sale, #edit_sale').attr('disabled', true);
                            }
                        }
                    });
                } else if (item_type == 'standard' && base_quantity > item_aqty) {
                    $('#row_' + row_no).addClass('danger');
                    if (site.settings.overselling != 1) {
                        $('#add_sale, #edit_sale').attr('disabled', true);
                    }
                } else if (item_type == 'combo') {
                    if (combo_items === false) {
                        $('#row_' + row_no).addClass('danger');
                        if (site.settings.overselling != 1) {
                            $('#add_sale, #edit_sale').attr('disabled', true);
                        }
                    } else {
                        $.each(combo_items, function() {
                            if (parseFloat(this.quantity) < parseFloat(this.qty) * base_quantity && this.type == 'standard') {
                                $('#row_' + row_no).addClass('danger');
                                if (site.settings.overselling != 1) {
                                    $('#add_sale, #edit_sale').attr('disabled', true);
                                }
                            }
                        });
                    }
                }
            });

            var col = 2;
            if (site.settings.product_serial == 1) {
                col++;
            }
            if (site.settings.IsCurtains == 1 || site.settings.IsEquipmentRental == 1) {
                col++;
            }
            var tfoot='';
            if (site.settings.isOpen_invoice == 1) {
                col--;
                  tfoot =
                '<tr id="tfoot" class="tfoot active"><th> <button id="addnOpenItemManually" class="tip" style="border-width:0px;"><i class="fa fa-plus"></i></button> </th><th colspan="' +
                col +
                '">Total</th><th class="text-center">' +
                formatQty(parseFloat(count) - 1) +
                '</th>';
            }else{
                 tfoot =
                '<tr id="tfoot" class="tfoot active"><th colspan="' +
                col +
                '">Total</th><th class="text-center">' +
                formatQty(parseFloat(count) - 1) +
                '</th>';

            }
            //if($('#tax_method_type').val()!=1)
            if ((site.settings.product_discount == 1 && allow_discount == 1) || product_discount) {
                tfoot += '<th class="text-right">' + formatMoney(product_discount,localStorage.getItem('slcurrency')) + '</th>';
            }
            //if($('#tax_method_type').val()!=1)
            if (site.settings.tax1 == 1) {
                tfoot += '<th class="text-right">' + formatMoney(product_tax,localStorage.getItem('slcurrency')) + '</th>';
            }
            tfoot +=
                '<th class="text-right">' +
                formatMoney(total,localStorage.getItem('slcurrency')) +
                '</th><th class="text-center"><i class="fa fa-trash-o" style="opacity:0.5; filter:alpha(opacity=50);"></i></th></tr>';
            $('#slTable tfoot').html(tfoot);

            // Order level discount calculations
            if ((sldiscount = localStorage.getItem('sldiscount'))) {
                var ds = sldiscount;
                if (ds.indexOf('%') !== -1) {
                    var pds = ds.split('%');
                    if (!isNaN(pds[0])) {
                        order_discount = formatDecimal((total * parseFloat(pds[0])) / 100, 12);
                    } else {
                        order_discount = formatDecimal(ds,12);
                    }
                } else {
                    order_discount = formatDecimal(ds,12);
                }

                //total_discount += parseFloat(order_discount);
            }
            order_discount=0;

            // Order level tax calculations
            if (site.settings.tax2 != 0) {
                if ((sltax2 = localStorage.getItem('sltax2'))) {
                    $.each(tax_rates, function() {
                        if (this.id == sltax2) {
                            if (this.type == 2) {
                                invoice_tax = formatDecimal(this.rate,12);
                            } else if (this.type == 1) {
                                invoice_tax = formatDecimal(((total - order_discount) * this.rate) / 100, 12);
                            }
                        }
                    });
                }
            }
            //alert($('#pdiscount').val());

            total_discount = parseFloat(order_discount + product_discount);
            // Totals calculations after item addition
            //alert(total);
            var gtotal = parseFloat(total + invoice_tax - order_discount + shipping);
            $('#total').text(formatMoney(total,localStorage.getItem('slcurrency')));
            $('#titems').text(an - 1 + ' (' + formatQty(parseFloat(count) - 1) + ')');
            $('#total_items').val(parseFloat(count) - 1);
            //$('#tds').text('('+formatMoney(product_discount)+'+'+formatMoney(order_discount)+')'+formatMoney(total_discount));
            $('#tds').text(formatMoney(order_discount,localStorage.getItem('slcurrency')));
            if (site.settings.tax2 != 0) {
                $('#ttax2').text(formatMoney(invoice_tax,localStorage.getItem('slcurrency')));
            }
            $('#tship').text(formatMoney(shipping,localStorage.getItem('slcurrency')));
            $('#gtotal').text(formatMoney(gtotal,localStorage.getItem('slcurrency')));
            if (an > parseInt(site.settings.bc_fix) && parseInt(site.settings.bc_fix) > 0) {
                $('html, body').animate({ scrollTop: $('#sticker').offset().top }, 500);
                $(window).scrollTop($(window).scrollTop() + 1);
            }
            if (count > 1 && ((sldebit_id = localStorage.getItem('sldebit_id')) || (slcredit_id = localStorage.getItem('slcredit_id')))) {
                $('#slcustomer').select2('readonly', true);
                $('#slwarehouse').select2('readonly', true);
                $('#slcurrency').select2('readonly', true);
                $('#grpId').select2('readonly', true);
                $('#coId').select2('readonly', true);
                $('#brId').select2('readonly', true);

            }
            set_page_focus();
        }
    }


    function getDiscount(){
        var discounttotal=0;
        try{

                //	 $('#tax_method_type').select2('readonly', false);

            slitems = JSON.parse(localStorage.getItem('slitems'));
            sortedItems =
                site.settings.item_addition == 1
                    ? _.sortBy(slitems, function(o) {
                          return [parseInt(o.order)];
                      })
                    : slitems;
            if(sortedItems.length!=0)
                $('#add_sale, #edit_sale').attr('disabled', false);
            $.each(sortedItems, function() {
                var item = this;
                var item_id = site.settings.item_addition == 1 ? item.item_id : item.id;
                if(item.unit_first!=null)
                item_id=item.id;
                item.order = item.order ? item.order : new Date().getTime();
                var product_id = item.row.id,
                    item_type = item.row.type,
                    combo_items = item.combo_items,
                    item_price = item.row.price,
                    item_area = item.row.area,
                    item_qty = item.row.qty,
                    item_aqty = item.row.quantity,
                    item_tax_method = item.row.tax_method,
                    item_ds = item.row.discount,
                    item_discount = 0,
                    item_option = item.row.option,
                    item_code = item.row.code,
                    item_serial = item.row.serial,
                    item_name = item.row.name.replace(/"/g, '&#034;').replace(/'/g, '&#039;');
                var product_unit = item.row.unit,
                    base_quantity = item.row.base_quantity;
                var unit_price = item.row.real_unit_price;
                if (item.units && item.row.fup != 1 && product_unit != item.row.base_unit) {
                    $.each(item.units, function() {
                        if (this.id == product_unit) {
                            base_quantity = formatDecimal(unitToBaseQty(item.row.qty, this), 12);
                            //unit_price = formatDecimal(parseFloat(item.row.base_unit_price) * unitToBaseQty(1, this), 12);



                        }
                    });
                }


                //alert(unit_price)

                var pr_tax = item.tax_rate;
                //if(!isset(old_item_tax))
                old_item_tax=pr_tax.id;
                var pr_tax_val = 0,
                    pr_tax_rate = 0;
                if (site.settings.tax1 == 1) {
                    if (pr_tax !== false && pr_tax != 0) {
                        if (pr_tax.type == 1) {

                            if (item_tax_method == '0') {
                                pr_tax_val = formatDecimal((unit_price * parseFloat(pr_tax.rate)) / (100 + parseFloat(pr_tax.rate)), 12);
                                //pr_tax_val = formatDecimal((unit_price * formatDecimal(pr_tax.rate,12)) / (100), 12);
                                pr_tax_rate = formatDecimal(pr_tax.rate,12) + '%';
                            } else {
                                pr_tax_val = formatDecimal((unit_price * formatDecimal(pr_tax.rate,12)) / 100, 12);

                                pr_tax_rate = formatDecimal(pr_tax.rate,12) + '%';
                            }
                        } else if (pr_tax.type == 2) {
                            pr_tax_val = parseFloat(pr_tax.rate);
                            pr_tax_rate = pr_tax.rate;
                        }
                        //product_tax += pr_tax_val * item_qty;
                    }
                }

               unit_price = item_tax_method == 0 ? formatDecimal(unit_price - pr_tax_val, 12) : formatDecimal(unit_price,12);
                //alert(item_qty)

                isTobacco=0;
                if (site.settings.isTobacco == 1){
                try{
                    $.ajax({
                            type: 'get',
                            async: false,
                            url: site.base_url + 'products/getCategoryById/' + item.row.category_id,
                            dataType: 'json',
                            data: { id : item.row.category_id},
                            success: function(data, page) {

                                if (data.isTobacco == 1) {
                                    isTobacco=1;


                                }else{
                                    isTobacco=0;
                                }

                            },
                        });

                    }catch(err){alert(err);}
                }

                if (site.settings.IsCurtains == 1 || site.settings.IsEquipmentRental == 1)
                unit_price=unit_price*item_area;
                if(isTobacco==1)
                unit_price=unit_price*2;
                //discounttotal=formatDecimal(discounttotal+(base_quantity*unit_price),12);
                discounttotal=formatDecimal(discounttotal+(item_qty*unit_price),12);
                //alert(discounttotal)



            });
            //var jsonData = JSON.parse(slitems);


                }catch(err){alert(err)}

        return discounttotal;
    }
    /* -----------------------------
     * Add Sale Order Item Function
     * @param {json} item
     * @returns {Boolean}
     ---------------------------- */
    function add_invoice_item(item) {
        if($('#tax_method_type').val()){
         $('#tax_method_type').select2('readonly', true);
         }else{
                bootbox.alert(lang.Select_tax_method_type);
                item = null;
                return;
           }
        if (count == 1) {

            slitems = {};
            if ($('#slwarehouse').val() && $('#slcustomer').val()) {
                $('#slcustomer').select2('readonly', true);
                $('#slwarehouse').select2('readonly', true);
                $('#slcurrency').select2('readonly', true);
                $('#grpId').select2('readonly', true);
                $('#coId').select2('readonly', true);
                $('#brId').select2('readonly', true);
            } else {
                if($('#slwarehouse').val()){
                    bootbox.alert(lang.Select_warehouse);
                }else if($('#slcustomer').val()){
                    bootbox.alert(lang.Select_customer);
                }

                item = null;
                return;
            }
        }
        if (item == null) return;

        var item_id = site.settings.item_addition == 1 ? item.item_id : item.id;

        if(item.unit_first!=null)
        item_id=item.id;


        if (slitems[item_id]) {





            if ($('#tax_method_type').val() == 1)

            if(slitems[item_id].row.tax_rate!=old_item_tax){

            bootbox.alert(lang.taxes_are_not_uniform_Please_change_the_tax_system_type);
            delete slitems[item_id];
                item = null;
                return;
            }


            var new_qty = parseFloat(slitems[item_id].row.qty) + 1;
            slitems[item_id].row.base_quantity = new_qty;
            if (slitems[item_id].row.unit != slitems[item_id].row.base_unit) {
                $.each(slitems[item_id].units, function() {
                    if (this.id == slitems[item_id].row.unit) {
                        slitems[item_id].row.base_quantity = unitToBaseQty(new_qty, this);
                    }
                });
            }
            slitems[item_id].row.qty = new_qty;
        } else {
            slitems[item_id] = item;
            if ($('#tax_method_type').val() == 1){
            if (count == 1){
            old_item_tax=slitems[item_id].row.tax_rate;

            //localStorage.setItem('sold_item_tax',old_item_tax);
            }
            //alert(old_item_tax);
            if(slitems[item_id].row.tax_rate!=old_item_tax){
                try{

            bootbox.alert(lang.taxes_are_not_uniform_Please_change_the_tax_system_type);
            delete slitems[item_id];
                item = null;
                return;
            }catch(err){alert(err)}
            }
        }
        if(slitems[item_id].row.real_unit_price < 0){

            bootbox.alert(lang.You_cannot_select_this_item_because_its_price_is_negative);
            delete slitems[item_id];
                item = null;
                return;
            }
        }
        slitems[item_id].order = new Date().getTime();

        //slitems[item_id].row.tax_rate=slitems[item_id].row.tax_rate / currRate;
        slitems[item_id].row.real_unit_price=slitems[item_id].row.real_unit_price / currRate;
        slitems[item_id].row.base_unit_price=slitems[item_id].row.base_unit_price / currRate;


        //alert(slitems[item_id].row.tax_rate)
        //console.log(slitems);
        localStorage.setItem('slitems', JSON.stringify(slitems));

        loadItems();
        return true;
    }

    if (typeof Storage === 'undefined') {
        $(window).bind('beforeunload', function(e) {
            if (count > 1) {
                var message = 'You will loss data!';
                return message;
            }
        });
    }
